# MARSWEAVE: 2-3 Minute Jury Demonstration Script
### NASA Space Apps Challenge 2026 Presentation Guide

Use this script to deliver an impactful, concise 2–3 minute demonstration to judging panels and reviewers.

---

### Step 1: Opening & The Paradigm Shift (0:00 – 0:30)
* **Visual:** Open MARSWEAVE. The dark, cinematic mission control interface fills the screen with Arcadia Planitia at the center.
* **Speaker:**
  > *"Judges, a future astronaut standing on Mars does not need another static map with layer toggles. They need an intelligent operational system that tells them where to walk, what to avoid, where to stop for science, and why. That is MARSWEAVE."*
  > *"MARSWEAVE fuses 10 heterogeneous NASA mission datasets—including MOLA altimetry, HiRISE 25cm imagery, SHARAD subsurface radar, CRISM hyperspectral data, and Perseverance MEDA weather—into an active decision-support system."*

---

### Step 2: Mission Setup & Multi-Objective Route Planning (0:30 – 1:00)
* **Action:**
  1. On the left panel under **MISSION CONFIGURATION**, select the **WATER & ICE** objective.
  2. Click **PLAN EVA MISSION**.
* **Visual:** Watch the multi-objective A* engine trace three distinct routes on the map: Route Alpha (Cyan), Route Beta (Purple), and Route Gamma (Red).
* **Speaker:**
  > *"When we select our scientific objective and click 'Plan EVA', MARSWEAVE doesn't draw a generic straight line. Notice Route Gamma—it is the shortest path, but it dangerously cuts across a 34° scree crater rim and loses communications. MARSWEAVE selects Route Alpha instead."*
  > *"On the right panel under 'WHY THIS ROUTE?', the system explains its engineering rationale: 18% lower slope exposure, 31% lower hazard risk, 2 high-value mineral targets intercepted, and continuous line-of-sight with the MRO relay."*

---

### Step 3: Science Target Inspection & Evidence Chain (1:00 – 1:30)
* **Action:** Click directly on **Target SCI-07** on the map (or click its card in the panel).
* **Visual:** The **Target Inspector & Evidence Chain Modal** opens.
* **Speaker:**
  > *"MARSWEAVE provides complete scientific explainability. When we inspect Target SCI-07, we see the actual CRISM diagnostic absorption doublets at 1.4 and 1.9 micrometers proving structural water in smectite clay. Below it is the verifiable Evidence Chain: CRISM spectral signatures confirmed by THEMIS thermal bedrock inertia and HiRISE stratigraphy."*
* **Action:** Close the modal.

---

### Step 4: Live Simulation & Dynamic Environmental Adaptation (1:30 – 2:15)
* **Action:** Click the **PLAY** button on the bottom timeline bar. Toggle speed to **5x**.
* **Visual:** The astronaut marker moves along Route Alpha with real-time vitals (battery %, suit $\text{O}_2$, heart rate) updating continuously.
* **Speaker:**
  > *"Now we simulate the EVA. As the astronaut walks, our vitals monitor suit battery, oxygen depletion, and radiation dose rate calibrated from MSL RAD."*
* **Action:** Click **JURY DEMO FLOW** in the top bar, or wait for the automatic dust surge at T+45min.
* **Visual:** The dynamic amber warning banner appears:
  `⚠ DUST STORM SURGE DETECTED (MRO MARCI/MCS): tau = 1.88`.
* **Speaker:**
  > *"Look at the map—an atmospheric dust front detected by MRO MARCI moves in, increasing optical depth and regolith slip hazards. The system immediately detects that the current route is degraded and offers a dynamic replan."*
* **Action:** Click **REPLAN EVA ROUTE**.
* **Visual:** The route recalculates instantly around the dust corridor, showing quantitative deltas ($\Delta\text{Risk} -22\%$, $\Delta\text{Comms} +11\%$).

---

### Step 5: Mission Debrief & Conclusion (2:15 – 2:30)
* **Action:** Click **REPORT** in the top right header.
* **Visual:** The **EVA Mission Debrief Report** appears with completed science samples, traversed distance, and NASA PDS archival citations.
* **Speaker:**
  > *"At mission completion, the astronaut and ground control receive an official debrief report cataloging every sample collected and citing verified NASA PDS archives."*
  > *"MARSWEAVE proves that the best route on Mars is mission-dependent. Thank you."*
