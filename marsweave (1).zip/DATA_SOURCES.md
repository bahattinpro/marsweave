# NASA Mission Data Sources & Provenance

MARSWEAVE integrates published NASA mission datasets across orbital altimetry, high-resolution cameras, imaging spectrometers, ground-penetrating radar, surface environmental stations, and energetic particle detectors.

---

### 1. MOLA — Mars Orbiter Laser Altimeter
- **Mission:** Mars Global Surveyor (MGS)
- **Agency:** NASA / Goddard Space Flight Center
- **Dataset ID:** `MGS-M-MOLA-5-MEGDR-L3-V1.0`
- **Measurement:** 1064 nm Nd:YAG laser altimetry
- **Spatial Resolution:** 128 pixels/degree ($\approx 463\text{ m/pixel}$ at equator)
- **Role in MARSWEAVE:** Forms the digital elevation model (DEM), hypsometric tint color map, macro-slope calculation, and hillshade azimuth rendering.
- **Scientific Caveat:** Sub-100m micro-roughness is augmented by HiRISE stereophotogrammetry.

---

### 2. HiRISE — High Resolution Imaging Science Experiment
- **Mission:** Mars Reconnaissance Orbiter (MRO)
- **Agency:** NASA / University of Arizona
- **Dataset ID:** `MRO-M-HIRISE-3-RDR-V1.1`
- **Measurement:** High-resolution visible & NIR imaging (RED 550-850 nm, BG 400-600 nm, NIR 800-1000 nm)
- **Spatial Resolution:** $25 - 30\text{ cm per pixel}$
- **Role in MARSWEAVE:** Detects decametric boulder fields, crater rim collapse scarps, and periglacial thermal contraction crack polygon networks.
- **Scientific Caveat:** HiRISE swathes are targeted; untargeted intermediate zones utilize CTX (Context Camera, 6 m/px) context interpolation.

---

### 3. SHARAD — Shallow Subsurface Radar
- **Mission:** Mars Reconnaissance Orbiter (MRO)
- **Agency:** NASA / ASI (Italian Space Agency)
- **Dataset ID:** `MRO-M-SHARAD-5-RADARGRAM-V1.0`
- **Measurement:** 15–25 MHz chirped synthetic aperture radar sounding
- **Spatial Resolution:** 15 m vertical in free space (higher in water-ice, $\varepsilon \approx 3.15$), 0.3–1 km along track
- **Role in MARSWEAVE:** Maps subsurface sheet-like excess ice deposits at depths of $1.5 - 4.2\text{ m}$ in Arcadia Planitia, deriving dielectric constant and ice purity percentages.
- **Scientific Caveat:** Radar reflections require clutter simulation to confirm that subsurface reflectors are not off-nadir surface topography echoes.

---

### 4. CRISM — Compact Reconnaissance Imaging Spectrometer for Mars
- **Mission:** Mars Reconnaissance Orbiter (MRO)
- **Agency:** NASA / Johns Hopkins University Applied Physics Laboratory (JHUAPL)
- **Dataset ID:** `MRO-M-CRISM-3-RDR-TARGETED-V1.0`
- **Measurement:** 544 spectral channels spanning 362 to 3920 nm
- **Spatial Resolution:** 18 to 36 m/pixel in Targeted Mode
- **Role in MARSWEAVE:** Identifies hydrated smectite clays, hydrated silica, and phyllosilicates through the diagnostic $1.41\text{ }\mu\text{m}$ (O-H stretch) and $1.92\text{ }\mu\text{m}$ ($\text{H}_2\text{O}$ vibrational bend) absorption doublets.
- **Scientific Caveat:** Volcano-scan atmospheric correction is applied to eliminate atmospheric $\text{CO}_2$ interference bands.

---

### 5. THEMIS — Thermal Emission Imaging System
- **Mission:** 2001 Mars Odyssey
- **Agency:** NASA / Arizona State University
- **Dataset ID:** `ODY-M-THM-5-DCS-V1.0`
- **Measurement:** 9 infrared bands (6.8 to 14.9 µm)
- **Spatial Resolution:** 100 m/pixel (Infrared)
- **Role in MARSWEAVE:** Computes nighttime thermal inertia to distinguish coherent rock outcrops from loose, insulating fine dust mantles.

---

### 6. MEDA — Mars Environmental Dynamics Analyzer
- **Mission:** Mars 2020 (Perseverance Rover)
- **Agency:** NASA / INTA-CSIC
- **Dataset ID:** `M2020-M-MEDA-3-RDR-V1.0`
- **Measurement:** Surface pressure, ground/air temperature, 3D wind velocity, relative humidity, and dust optical depth (RDS).
- **Role in MARSWEAVE:** Provides calibrated in-situ baseline measurements scaled to Arcadia Planitia's latitude ($39^\circ\text{N}$) and pressure (~680 Pa).

---

### 7. RAD — Radiation Assessment Detector
- **Mission:** Mars Science Laboratory (Curiosity Rover)
- **Agency:** NASA / Southwest Research Institute (SwRI)
- **Dataset ID:** `MSL-M-RAD-3-RDR-V1.0`
- **Measurement:** Surface energetic charged particles (protons to iron nuclei) and neutral neutrons/gamma rays.
- **Role in MARSWEAVE:** Calibrates nominal surface astronaut dose rates ($\sim 24 - 32\text{ }\mu\text{Sv/h}$).

---

### 8. Mars Relay Network
- **Mission:** MRO, 2001 Mars Odyssey, Trace Gas Orbiter (TGO), MAVEN
- **Agency:** NASA / ESA
- **Role in MARSWEAVE:** Calculates line-of-sight elevation angles and terrain shadow masks for the UHF Proximity-1 communications link between the EVA crew and orbiting relay spacecraft.
