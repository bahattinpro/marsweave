# MARSWEAVE
### *Intelligent EVA Planning for the Red Planet*

> **"A future astronaut does not need another static Mars map. They need to know where to walk, when to walk, what to avoid, where to stop, what to investigate, and why."**

[![NASA Space Apps Challenge 2026](https://img.shields.io/badge/NASA%20Space%20Apps-2026%20Challenge-orange.svg)](https://www.spaceappschallenge.org/)
[![License: Apache-2.0](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](LICENSE)
[![Status: Production Aerospace Prototype](https://img.shields.io/badge/Status-Aerospace%20Prototype-emerald.svg)]()

---

## 1. What is MARSWEAVE?
**MARSWEAVE** is an interactive surface mission-planning and scientific exploration platform engineered for future human extravehicular activity (EVA) on the Martian surface. 

Rather than functioning as a passive GIS viewer with layer checkboxes, MARSWEAVE converts heterogeneous NASA orbital and in-situ datasets into an **explainable, multi-objective traversal plan**. When an astronaut or mission controller defines a starting habitat and science targets, the system simultaneously evaluates terrain elevation slopes, boulder scree, subsurface water ice deposits, mineralogical spectra, orbital relay communications, atmospheric dust opacity, and life-support constraints.

---

## 2. NASA Challenge Addressed
* **Challenge:** Interplanetary Survival Guide: Martian Map (NASA Space Apps Challenge 2026)
* **Core Philosophy:** Transform multi-mission NASA datasets into an active decision-support and exploration system that enables human explorers to work safely, efficiently, and discover more on Mars.

---

## 3. The Problem
Current planetary mapping tools display layers in isolation:
* An astronaut or planner sees MOLA elevation on one map, CRISM spectral signatures on another, and SHARAD radar echograms in a scientific paper.
* Standard routing engines (such as Dijkstra or road navigation) simply minimize geometric distance (A → B). On Mars, the shortest route can be fatal: traversing a 34° loose scree crater rim, descending into a communication shadow zone, or bypassing high-value astrobiological discoveries by just 150 meters.

---

## 4. The Solution: Multi-Objective EVA Optimization
MARSWEAVE solves this through a multi-objective cost optimization:

$$\text{Route Cost} = \alpha \cdot d + \beta \cdot \text{SlopePenalty} + \gamma \cdot \text{BoulderHazard} + \delta \cdot \text{CommsLoss} + \epsilon \cdot \text{DustFriction} - \omega \cdot \text{ScienceYield} - \zeta \cdot \text{IceProximity}$$

Where weights $(\alpha, \beta, \gamma, \delta, \epsilon, \omega, \zeta)$ are dynamically governed by the **Mission Objective** (`WATER`, `MINERALOGY`, `GEOLOGY`, `TERRAIN_SURVEY`, `MULTI_SCIENCE`) and **Risk Tolerance** (`LOW`, `MEDIUM`, `HIGH`).

---

## 5. NASA Datasets & Mission Provenance
Every layer and waypoint in MARSWEAVE is grounded in published NASA mission data:

| Instrument | Mission | Agency | Role in MARSWEAVE | PDS Release Citation |
| :--- | :--- | :--- | :--- | :--- |
| **MOLA** | Mars Global Surveyor | NASA / GSFC | Digital Elevation Model, hypsometric tint, macro-slope | `MGS-M-MOLA-5-MEGDR-L3-V1.0` |
| **HiRISE** | Mars Reconnaissance Orbiter | NASA / UArizona | 25 cm/px boulder distribution, micro-relief, fracture polygons | `MRO-M-HIRISE-3-RDR-V1.1` |
| **SHARAD** | Mars Reconnaissance Orbiter | NASA / ASI | Shallow radar sounding, subsurface water-ice purity ($\varepsilon = 3.12$) | `MRO-M-SHARAD-5-RADARGRAM-V1.0` |
| **CRISM** | Mars Reconnaissance Orbiter | NASA / JHUAPL | Hyperspectral absorption (1.4 µm, 1.9 µm smectite clays, silica) | `MRO-M-CRISM-3-RDR-TARGETED-V1.0` |
| **THEMIS** | 2001 Mars Odyssey | NASA / ASU | Thermal inertia (rock vs loose dust), diurnal surface temperatures | `ODY-M-THM-5-DCS-V1.0` |
| **MEDA** | Mars 2020 (Perseverance) | NASA / INTA | Atmospheric boundary layer, wind shear, ground temperature baseline | `M2020-M-MEDA-3-RDR-V1.0` |
| **RAD** | Curiosity Rover (MSL) | NASA / SwRI | Galactic cosmic ray & solar particle radiation dose (~28 µSv/h) | `MSL-M-RAD-3-RDR-V1.0` |
| **MCS & MARCI**| Mars Reconnaissance Orbiter | NASA / MSSS | Column dust optical depth ($\tau$), regional storm front dynamics | `MRO-M-MCS-5-DDR-V1.0` |
| **Mars Relay** | MRO / Odyssey / TGO | NASA / ESA | Proximity-1 link geometry, line-of-sight elevation corridor | `MRN-ORBITAL-EPHEMERIS-2026` |

---

## 6. System Architecture
```
                                 NASA PDS ARCHIVE
         [MOLA] [HiRISE] [SHARAD] [CRISM] [THEMIS] [MEDA] [RAD] [MARCI]
                                         │
                                         ▼
                     GEOSPATIAL & HAZARD NORMALIZATION ENGINE
             (Arcadia Planitia 50x50 Aerocentric Surface Grid Matrix)
                                         │
                   ┌─────────────────────┴─────────────────────┐
                   ▼                                           ▼
         MULTI-OBJECTIVE A*                          REAL-TIME TELEMETRY
         ROUTE OPTIMIZER                             & CONTINGENCY SIMULATOR
  (Slope, Comms, Boulders, Science)             (Dust Front, Battery, O2, Rad)
                   │                                           │
                   └─────────────────────┬─────────────────────┘
                                         ▼
                         MARSWEAVE SCIENTIFIC MISSION HUD
             [Geospatial Canvas] [Why This Route?] [Evidence Chains]
               [What-If Engine] [Mission Copilot] [Debrief Report]
```

---

## 7. Key Features
1. **Interactive Mars Surface Viewport**: Full GPU-accelerated canvas renderer with true aerocentric coordinates ($39.3^\circ\text{N}, 171.4^\circ\text{W}$), MOLA hillshade, contour intervals, and multi-spectral overlays.
2. **"WHY THIS ROUTE?" Explainable AI**: Detailed metric comparison explaining why Route Alpha was selected over Route Beta and Route Gamma.
3. **Multi-Tier Evidence Chain**: Click any science target to inspect the verifiable sequence of NASA observations behind the classification.
4. **Interactive Mission Simulator**: Scrub timeline from $00:00$ to $120:00$, monitoring battery, suit $\text{O}_2$, heart rate, and environmental conditions.
5. **Dynamic Replanning**: When a regional dust storm surge is detected, the system immediately calculates an alternate route with exact quantitative deltas ($\Delta\text{Time}$, $\Delta\text{Risk}$, $\Delta\text{Science}$, $\Delta\text{Comms}$).
6. **"WHAT IF?" Contingency Engine**: Test hypothetical scenarios (e.g., $+50\%$ dust optical depth, early satellite loss-of-signal, or impaired astronaut climbing mobility).
7. **MARSWEAVE COPILOT**: Server-side Gemini 3.8 Flash operational copilot grounded in live telemetry and NASA instruments.
8. **Final EVA Mission Report**: Comprehensive debrief with printable operational certificate.

---

## 8. Installation & Running Locally

```bash
# Clone the repository
git clone https://github.com/nasa-space-apps-2026/marsweave.git
cd marsweave

# Install dependencies
npm install

# Set up environment variables
cp .env.example .env
# Edit .env and supply your GEMINI_API_KEY (optional, app has offline fallback)

# Run development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

---

## 9. 🐙 GitHub Pages ile Yayınlama (Deployment Guide)

Eğer kodlarınızı güncelledikçe sitenizin de otomatik olarak güncellenmesini istiyorsanız, en profesyonel ücretsiz yöntem GitHub Pages ve GitHub Actions entegrasyonudur.

### Adım Adım Kurulum:
1. **GitHub Deposu Oluşturun:**
   - GitHub üzerinde ücretsiz bir hesap açın ve yeni bir depo (**Repository**) oluşturun (örn: `marsweave`).
2. **Kodlarınızı Depoya Yükleyin:**
   ```bash
   git init
   git add .
   git commit -m "MARSWEAVE: Initial deployment"
   git branch -M main
   git remote add origin https://github.com/<kullanici-adiniz>/<depo-adiniz>.git
   git push -u origin main
   ```
3. **Deponun Ayarlarına Gidin:**
   - Depo sayfasında **Settings** (Ayarlar) > **Pages** menüsüne gidin.
4. **Build and Deployment Ayarını Yapın:**
   - **Tavsiye Edilen (Otomatik CI/CD):** *Source* alanından **GitHub Actions** seçin. Projede hazır bulunan `.github/workflows/deploy.yml` sayesinde her `git push` yaptığınızda siteniz otomatik olarak derlenir ve güncellenir.
   - **Alternatif (Klasik Branch):** *Source* alanında **Deploy from a branch** seçin, *Branch* kısmını **Main**, klasörü **/docs** olarak seçip kaydedin.
5. **Canlı Yayına Ulaşın:**
   - Birkaç dakika içinde siteniz `https://<kullanici-adiniz>.github.io/<depo-adiniz>/` adresinde yayına girecektir.

---

## 10. Space Apps Challenge Presentation Statement
* **Central Statement:** *"The best route is mission-dependent."*
* **Mission Loop:** `OBSERVE → UNDERSTAND → PLAN → WALK → DISCOVER → ADAPT`

