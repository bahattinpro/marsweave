# MARSWEAVE Scientific & Computational Methodology

## 1. Multi-Objective Route Optimization
Standard navigation systems solve for the shortest Euclidean or Manhattan path. In planetary exploration, terrain steepness, geomechanical hazards, scientific harvest, and life-support consumption dictate operational feasibility.

### Mathematical Formulation
Let the exploration terrain be modeled as a directed weighted graph $G = (V, E)$. For an edge $(u, v) \in E$ connecting adjacent grid cells, the operational cost $C(u, v)$ is formulated as:

$$C(u, v) = w_d \cdot d(u, v) + P_{\text{slope}}(v) + P_{\text{hazard}}(v) + P_{\text{comms}}(v) - R_{\text{science}}(v) - R_{\text{ice}}(v)$$

Where:
1. **Distance Metric:** $d(u, v) = \sqrt{\Delta x^2 + \Delta y^2}$, scaled by grid cell dimensions ($136\text{ m}$).
2. **Slope Penalty Function:**
   $$P_{\text{slope}}(v) = \begin{cases} 
   0 & \text{if } \theta(v) \le 14^\circ \\
   w_s \cdot \left(\frac{\theta(v) - 14}{4}\right)^{1.8} & \text{if } 14^\circ < \theta(v) \le \theta_{\text{max}} \\
   \infty & \text{if } \theta(v) > \theta_{\text{max}}
   \end{cases}$$
   where $\theta_{\text{max}} = 25^\circ$ for nominal pressurized suits and $14^\circ$ under mobility contingency.
3. **Hazard Penalty:**
   $$P_{\text{hazard}}(v) = w_h \cdot H(v) \cdot 8.0$$
   where $H(v) \in [0, 1]$ represents normalized boulder density and rim scree risk.
4. **Communication Shadow Penalty:**
   $$P_{\text{comms}}(v) = \begin{cases}
   w_c \cdot \left(\frac{75 - \text{LOS}(v)}{25}\right) \cdot 4.0 & \text{if } \text{LOS}(v) < 75\% \\
   0 & \text{otherwise}
   \end{cases}$$
5. **Science Target & Ice Attraction Bonuses:**
   $$R_{\text{science}}(v) = w_{\text{sci}} \cdot \frac{V_{\text{target}}}{100}, \quad R_{\text{ice}}(v) = w_{\text{ice}} \cdot \max\left(0, \frac{\text{IceProb}(v) - 65}{35}\right)$$

---

## 2. Dynamic Candidate Generation
The route optimizer generates three distinct profiles for comparison:
- **Route Alpha (Balanced Science & Safety):** Optimized using nominal mission weights ($w_s=2.4, w_h=3.0, w_{\text{sci}}=1.8, w_c=1.6$).
- **Route Beta (Maximum Science Yield):** Biased toward intermediate mineralogical and periglacial waypoints ($w_{\text{sci}}=5.04, w_{\text{ice}}=3.75, w_s=1.68$).
- **Route Gamma (Direct Transit):** Minimizes pure distance ($w_d=4.0$), accepting elevated scree slope exposure and communication blindspots for rapid retreat.

---

## 3. Evidence Chain Verification
Every scientific target presents an empirical chain of causality:
$$\text{Orbital Spectrometer / Radar} \longrightarrow \text{Physical Absorption / Dielectric Echo} \longrightarrow \text{Mineral / Ice Composition} \longrightarrow \text{Sampling Protocol}$$

Example for Target SCI-07:
1. **CRISM:** Deep absorption doublets at $1.41\text{ }\mu\text{m}$ and $1.92\text{ }\mu\text{m}$ $\to$ structural $\text{H}_2\text{O}$ in smectite lattice $\to$ neutral/alkaline paleolake alteration.
2. **THEMIS:** Thermal inertia $380\text{ J m}^{-2}\text{ K}^{-1}\text{ s}^{-1/2}$ $\to$ indurated coherent bedrock with negligible mobile dust mantle.
3. **HiRISE:** Sub-meter layered bench geometry with $4^\circ$ dip $\to$ safe pedestrian accessibility for rover core drilling.

---

## 4. Differential Replanning Engine
When environmental conditions degrade (such as atmospheric dust opacity increasing from $\tau = 0.54$ to $\tau = 1.88$), the route optimizer re-runs pathfinding from the astronaut's active coordinate. The system outputs quantitative comparison vectors:
- $\Delta\text{Distance} = d_{\text{new}} - d_{\text{orig}}$
- $\Delta\text{Time} = t_{\text{new}} - t_{\text{orig}}$
- $\Delta\text{Risk} = \frac{R_{\text{new}} - R_{\text{orig}}}{R_{\text{orig}}} \times 100\%$
- $\Delta\text{Comms} = C_{\text{new}} - C_{\text{orig}}$
