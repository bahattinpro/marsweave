/**
 * MARSWEAVE — Intelligent EVA Planning for the Red Planet
 * Main Application Orchestrator & State Machine
 */

import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import {
  MissionProfile,
  LayerMetadata,
  ScienceTarget,
  HazardZone,
  RouteCandidate,
  EnvironmentalConditions,
  AstronautTelemetry,
  EnvironmentalAlert,
  WhatIfScenarioOption,
  RouteComparisonDelta
} from './types/marsweave';
import {
  INITIAL_DATA_LAYERS,
  ARCADIA_SCIENCE_TARGETS,
  ARCADIA_HAZARD_ZONES,
  HABITAT_ALPHA,
  DEFAULT_TARGET_ID,
  INITIAL_ENVIRONMENTAL_CONDITIONS
} from './data/arcadiaData';
import {
  planEvaRoutes,
  calculateReplanningDelta
} from './engine/routeOptimizer';
import { MarsMapCanvas, CellInspectionInfo } from './components/MarsMap/MarsMapCanvas';
import { HeaderBar, PageId } from './components/Header/HeaderBar';
import { HomePage } from './components/Pages/HomePage';
import { ProblemPage } from './components/Pages/ProblemPage';
import { HowItWorksPage } from './components/Pages/HowItWorksPage';
import { NasaDataPage } from './components/Pages/NasaDataPage';
import { SciencePage } from './components/Pages/SciencePage';
import { SourcesPage } from './components/Pages/SourcesPage';
import { MissionBriefingModal } from './components/Modals/MissionBriefingModal';
import { ScienceDecisionModal } from './components/Modals/ScienceDecisionModal';
import { MissionSetupPanel } from './components/Panels/MissionSetupPanel';
import { RoutePanel } from './components/Panels/RoutePanel';
import { LayerManagerPanel } from './components/Panels/LayerManagerPanel';
import { SimulatorControls } from './components/Panels/SimulatorControls';
import { ScienceTargetModal } from './components/Modals/ScienceTargetModal';
import { WhatIfModal } from './components/Modals/WhatIfModal';
import { MissionCopilot } from './components/Copilot/MissionCopilot';
import { DataProvenanceDrawer } from './components/Panels/DataProvenanceDrawer';
import { MissionReportModal } from './components/Modals/MissionReportModal';
import { JuryTourModal } from './components/Modals/JuryTourModal';
import { GithubPagesModal } from './components/Modals/GithubPagesModal';
import {
  Layers,
  Compass,
  Route,
  ChevronLeft,
  ChevronRight,
  Maximize2,
  RefreshCw,
  Sparkles
} from 'lucide-react';

export default function App() {
  // 1. Mission Configuration Profile State
  const [profile, setProfile] = useState<MissionProfile>({
    objective: 'WATER',
    durationMin: 120,
    riskTolerance: 'LOW',
    sciencePriority: 'HIGH',
    commsPriority: 'HIGH',
    astronautSpeedMpm: 42,
    batteryBudgetWh: 800,
    o2BudgetLiters: 1200
  });

  // 2. Data Layers State
  const [layers, setLayers] = useState<LayerMetadata[]>(INITIAL_DATA_LAYERS);

  // 3. Targets and Coordinates State
  const [scienceTargets, setScienceTargets] = useState<ScienceTarget[]>(ARCADIA_SCIENCE_TARGETS);
  const [hazardZones, setHazardZones] = useState<HazardZone[]>(ARCADIA_HAZARD_ZONES);
  const [startPoint, setStartPoint] = useState<[number, number]>([HABITAT_ALPHA.x, HABITAT_ALPHA.y]);
  const [targetPoint, setTargetPoint] = useState<[number, number]>([
    ARCADIA_SCIENCE_TARGETS[0].x,
    ARCADIA_SCIENCE_TARGETS[0].y
  ]);
  const [selectedTargetId, setSelectedTargetId] = useState<string>(DEFAULT_TARGET_ID);

  // 4. Routes State (lazy initialized so planEvaRoutes is not re-executed on every render)
  const [routes, setRoutes] = useState<RouteCandidate[]>(() =>
    planEvaRoutes(
      [HABITAT_ALPHA.x, HABITAT_ALPHA.y],
      [ARCADIA_SCIENCE_TARGETS[0].x, ARCADIA_SCIENCE_TARGETS[0].y],
      profile
    ).routes
  );
  const [selectedRoute, setSelectedRoute] = useState<RouteCandidate>(() =>
    planEvaRoutes(
      [HABITAT_ALPHA.x, HABITAT_ALPHA.y],
      [ARCADIA_SCIENCE_TARGETS[0].x, ARCADIA_SCIENCE_TARGETS[0].y],
      profile
    ).selectedRoute
  );
  const [isPlanning, setIsPlanning] = useState<boolean>(false);

  // 5. Environmental & Mission Progress State
  const [environment, setEnvironment] = useState<EnvironmentalConditions>(INITIAL_ENVIRONMENTAL_CONDITIONS);
  const [dustStormActive, setDustStormActive] = useState<boolean>(false);
  const [completedObservations, setCompletedObservations] = useState<string[]>([]);
  const [samplesCollected, setSamplesCollected] = useState<string[]>([]);

  // 6. Simulation State
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(2);
  const [currentElapsedSec, setCurrentElapsedSec] = useState<number>(0);
  const [activeAlert, setActiveAlert] = useState<EnvironmentalAlert | null>(null);
  const [isPerformingObservation, setIsPerformingObservation] = useState<boolean>(false);

  // 7. Page Navigation & Modals Visibility
  const [currentPage, setCurrentPage] = useState<PageId>('SIMULATOR');
  const [leftPanelMode, setLeftPanelMode] = useState<'SETUP' | 'LAYERS' | 'HIDDEN'>('SETUP');
  const [rightPanelOpen, setRightPanelOpen] = useState<boolean>(true);
  const [activeScienceModalTarget, setActiveScienceModalTarget] = useState<ScienceTarget | null>(null);
  const [scienceDecisionTarget, setScienceDecisionTarget] = useState<ScienceTarget | null>(null);
  const [isBriefingOpen, setIsBriefingOpen] = useState<boolean>(false);
  const [isWhatIfModalOpen, setIsWhatIfModalOpen] = useState<boolean>(false);
  const [isCopilotOpen, setIsCopilotOpen] = useState<boolean>(false);
  const [isProvenanceOpen, setIsProvenanceOpen] = useState<boolean>(false);
  const [provenanceFilter, setProvenanceFilter] = useState<string>('');
  const [isReportOpen, setIsReportOpen] = useState<boolean>(false);
  const [isJuryTourOpen, setIsJuryTourOpen] = useState<boolean>(false);
  const [isGithubPagesOpen, setIsGithubPagesOpen] = useState<boolean>(false);
  const alertTriggeredRef = useRef<boolean>(false);

  // Total Duration in seconds for simulation
  const totalDurationSec = selectedRoute.totalDurationMin * 60;

  /**
   * Calculate Astronaut Position along Waypoints (Memoized pure function)
   */
  const currentAstronautPos = useMemo<[number, number]>(() => {
    if (selectedRoute.waypoints.length === 0) return startPoint;
    if (currentElapsedSec <= 0) return [selectedRoute.waypoints[0].x, selectedRoute.waypoints[0].y];

    const progressRatio = Math.min(1, currentElapsedSec / totalDurationSec);
    const targetIdx = progressRatio * (selectedRoute.waypoints.length - 1);
    const baseIdx = Math.floor(targetIdx);
    const fract = targetIdx - baseIdx;

    if (baseIdx >= selectedRoute.waypoints.length - 1) {
      const last = selectedRoute.waypoints[selectedRoute.waypoints.length - 1];
      return [last.x, last.y];
    }

    const p1 = selectedRoute.waypoints[baseIdx];
    const p2 = selectedRoute.waypoints[baseIdx + 1];

    const curX = p1.x + (p2.x - p1.x) * fract;
    const curY = p1.y + (p2.y - p1.y) * fract;
    return [curX, curY];
  }, [selectedRoute.waypoints, startPoint, currentElapsedSec, totalDurationSec]);

  /**
   * Nearby science target detection (Memoized pure function)
   */
  const nearbyScienceTarget = useMemo(() => {
    const [ax, ay] = currentAstronautPos;
    return scienceTargets.find(t => Math.hypot(t.x - ax, t.y - ay) < 5.0) || null;
  }, [currentAstronautPos, scienceTargets]);

  /**
   * Astronaut Telemetry calculation (Memoized pure function, zero re-render cascade)
   */
  const astronautTelemetry: AstronautTelemetry = useMemo(() => {
    const progressRatio = Math.min(1, currentElapsedSec / totalDurationSec);
    const currentDistMeters = Math.round(progressRatio * selectedRoute.totalDistanceKm * 1000);
    const batteryRemaining = Math.max(10, 100 - (progressRatio * selectedRoute.energyConsumptionPct));
    const o2Remaining = Math.max(15, 100 - (progressRatio * selectedRoute.suitOxygenUsedPct));

    return {
      heartRateBpm: 98 + Math.round(Math.sin(currentElapsedSec * 0.05) * 16),
      suitPressureKpa: 29.6,
      suitO2RemainingPct: o2Remaining,
      suitBatteryRemainingPct: batteryRemaining,
      metabolicRateWatts: 240,
      currentDistanceMeters: currentDistMeters,
      currentElevationMeters: HABITAT_ALPHA.elevationMeters,
      timeRemainingMin: Math.max(0, Math.round((totalDurationSec - currentElapsedSec) / 60)),
      samplesCollected,
      completedObservations
    };
  }, [currentElapsedSec, totalDurationSec, selectedRoute, samplesCollected, completedObservations]);

  /**
   * Re-plans EVA routes using current parameters
   */
  const handlePlanEva = useCallback((dustMult: number = 1.0, commsMult: number = 1.0) => {
    setIsPlanning(true);
    setTimeout(() => {
      const plan = planEvaRoutes(startPoint, targetPoint, profile, dustMult, commsMult);
      setRoutes(plan.routes);
      setSelectedRoute(plan.selectedRoute);
      setIsPlanning(false);
    }, 350);
  }, [startPoint, targetPoint, profile]);

  /**
   * Handle Target Dropdown selection
   */
  const handleSelectTargetId = (id: string) => {
    setSelectedTargetId(id);
    const found = scienceTargets.find(t => t.id === id);
    if (found) {
      setTargetPoint([found.x, found.y]);
      // Re-plan with new destination
      const plan = planEvaRoutes(startPoint, [found.x, found.y], profile);
      setRoutes(plan.routes);
      setSelectedRoute(plan.selectedRoute);
    }
  };

  /**
   * Toggle Layer Visibility
   */
  const handleToggleLayer = (id: string) => {
    setLayers(prev =>
      prev.map(l => (l.id === id ? { ...l, visible: !l.visible } : l))
    );
  };

  /**
   * Change Layer Opacity
   */
  const handleChangeOpacity = (id: string, opacity: number) => {
    setLayers(prev =>
      prev.map(l => (l.id === id ? { ...l, opacity } : l))
    );
  };

  /**
   * Simulation Timer Tick
   */
  useEffect(() => {
    if (!isPlaying) return;

    const interval = setInterval(() => {
      let reachedEnd = false;
      let shouldAlert = false;
      let tickTime = 0;

      setCurrentElapsedSec(prev => {
        const next = prev + 1 * playbackSpeed;
        if (next >= totalDurationSec) {
          reachedEnd = true;
          tickTime = totalDurationSec;
          return totalDurationSec;
        }

        if (next >= 2700 && next < 2700 + 4 * playbackSpeed) {
          shouldAlert = true;
        }
        tickTime = next;
        return next;
      });

      if (reachedEnd) {
        setIsPlaying(false);
        setIsReportOpen(true);
      } else if (shouldAlert && !alertTriggeredRef.current) {
        alertTriggeredRef.current = true;
        setDustStormActive(true);
        setEnvironment(env => ({
          ...env,
          dustOpticalDepthTau: 1.88,
          windSpeedMs: 14.6
        }));
        setActiveAlert({
          id: 'ALERT_DUST_01',
          type: 'DUST_STORM_SURGE',
          title: '⚠ DUST STORM SURGE DETECTED (MRO MARCI / MCS)',
          message: 'Atmospheric optical depth surged to tau = 1.88. Regolith slip hazard escalated on steep crater rims.',
          severity: 'CRITICAL',
          triggerAtElapsedSec: tickTime,
          impactTimeDeltaMin: 18,
          impactRiskDeltaPct: 35,
          suggestedAction: 'Reroute onto firm low-gradient bedrock bench to preserve traction.',
          resolved: false
        });
      }
    }, 100);

    return () => clearInterval(interval);
  }, [isPlaying, playbackSpeed, totalDurationSec]);

  /**
   * Trigger Science In-Situ Observation
   */
  const handlePerformScienceObservation = (target: ScienceTarget) => {
    setIsPerformingObservation(true);
    setTimeout(() => {
      setIsPerformingObservation(false);
      setCompletedObservations(prev => (prev.includes(target.id) ? prev : [...prev, target.id]));
      setSamplesCollected(prev => {
        const item = `${target.id}: ${target.name}`;
        return prev.includes(item) ? prev : [...prev, item];
      });
    }, 1800);
  };

  /**
   * Trigger Dynamic Re-planning in Response to Environmental Alert
   */
  const handleTriggerReplanning = () => {
    const plan = planEvaRoutes(startPoint, targetPoint, profile, 1.6, 0.7); // Apply high dust penalty
    setRoutes(plan.routes);
    setSelectedRoute(plan.selectedRoute);

    if (activeAlert) {
      setActiveAlert(a => (a ? { ...a, resolved: true } : null));
    }
  };

  /**
   * What-If Scenario Application
   */
  const handleSimulateScenario = useCallback((scenario: WhatIfScenarioOption) => {
    const tempProfile = {
      ...profile,
      durationMin: scenario.durationBudgetMin
    };
    const plan = planEvaRoutes(
      startPoint,
      targetPoint,
      tempProfile,
      scenario.dustModifier,
      scenario.commsModifier
    );
    const comparison = calculateReplanningDelta(selectedRoute, plan.selectedRoute);
    return {
      adaptedRoute: plan.selectedRoute,
      comparison
    };
  }, [profile, startPoint, targetPoint, selectedRoute]);

  const handleApplyWhatIfScenario = useCallback((scenario: WhatIfScenarioOption) => {
    setProfile(prev => ({
      ...prev,
      durationMin: scenario.durationBudgetMin
    }));
    const plan = planEvaRoutes(
      startPoint,
      targetPoint,
      profile,
      scenario.dustModifier,
      scenario.commsModifier
    );
    setRoutes(plan.routes);
    setSelectedRoute(plan.selectedRoute);
    if (scenario.dustModifier > 1.2) {
      setDustStormActive(true);
      setEnvironment(e => ({ ...e, dustOpticalDepthTau: 1.65 }));
    }
  }, [profile, startPoint, targetPoint]);

  return (
    <div className="flex flex-col h-screen w-screen bg-[#07090e] text-[#e2e8f0] overflow-hidden select-none font-sans">
      {/* 1. TOP HEADER & TELEMETRY RIBBON */}
      <HeaderBar
        currentPage={currentPage}
        onNavigate={page => {
          if (page === 'MISSION REPORT') {
            setIsReportOpen(true);
          } else {
            setCurrentPage(page);
          }
        }}
        onOpenWhatIf={() => setIsWhatIfModalOpen(true)}
        onOpenCopilot={() => setIsCopilotOpen(true)}
        onOpenProvenance={() => {
          setProvenanceFilter('');
          setIsProvenanceOpen(true);
        }}
        onOpenReport={() => setIsReportOpen(true)}
        onStartDemoTour={() => setIsJuryTourOpen(true)}
        onOpenBriefing={() => setIsBriefingOpen(true)}
        onOpenGithubPages={() => setIsGithubPagesOpen(true)}
        currentSol={environment.sol}
        localSolarTime={environment.marsLocalTime}
        dustTau={environment.dustOpticalDepthTau}
        commsPct={environment.commsQualityPct}
      />

      {/* EDITORIAL SCIENTIFIC PAGES */}
      {currentPage === 'HOME' && (
        <HomePage
          onNavigate={p => {
            if (p === 'MISSION REPORT') setIsReportOpen(true);
            else setCurrentPage(p as PageId);
          }}
          onLaunchSimulator={() => setCurrentPage('SIMULATOR')}
          onOpenGithubPages={() => setIsGithubPagesOpen(true)}
        />
      )}
      {currentPage === 'THE PROBLEM' && (
        <ProblemPage onLaunchSimulator={() => setCurrentPage('SIMULATOR')} />
      )}
      {currentPage === 'HOW IT WORKS' && (
        <HowItWorksPage onLaunchSimulator={() => setCurrentPage('SIMULATOR')} />
      )}
      {currentPage === 'NASA DATA' && <NasaDataPage />}
      {currentPage === 'SCIENCE' && (
        <SciencePage onLaunchSimulator={() => setCurrentPage('SIMULATOR')} />
      )}
      {currentPage === 'SOURCES' && <SourcesPage />}

      {/* 2. MAIN SIMULATOR & INTERACTIVE MAP VIEWPORT */}
      {currentPage === 'SIMULATOR' && (
        <>
          <div className="flex-1 flex overflow-hidden relative">
            {/* LEFT DOCKED PANEL: SETUP / LAYERS */}
            {leftPanelMode !== 'HIDDEN' && (
              <aside className="w-80 h-full flex flex-col z-20 shrink-0 shadow-2xl relative">
                {/* Mode Switcher Tabs */}
                <div className="flex bg-[#070b13] border-b border-[#1a2333] text-[10.5px] font-mono">
                  <button
                    onClick={() => setLeftPanelMode('SETUP')}
                    className={`flex-1 py-2 flex items-center justify-center gap-1.5 transition ${
                      leftPanelMode === 'SETUP'
                        ? 'text-[#e25c2b] border-b-2 border-[#e25c2b] font-bold bg-[#e25c2b]/10'
                        : 'text-gray-400 hover:text-white'
                    }`}
                  >
                    <Compass className="w-3.5 h-3.5" />
                    <span>MISSION SETUP</span>
                  </button>
                  <button
                    onClick={() => setLeftPanelMode('LAYERS')}
                    className={`flex-1 py-2 flex items-center justify-center gap-1.5 transition ${
                      leftPanelMode === 'LAYERS'
                        ? 'text-[#38bdf8] border-b-2 border-[#38bdf8] font-bold bg-[#38bdf8]/10'
                        : 'text-gray-400 hover:text-white'
                    }`}
                  >
                    <Layers className="w-3.5 h-3.5" />
                    <span>NASA LAYERS</span>
                  </button>
                </div>

                {/* Panel View */}
                <div className="flex-1 overflow-hidden">
                  {leftPanelMode === 'SETUP' ? (
                    <MissionSetupPanel
                      profile={profile}
                      onChangeProfile={p => {
                        setProfile(p);
                        handlePlanEva();
                      }}
                      scienceTargets={scienceTargets}
                      selectedTargetId={selectedTargetId}
                      onSelectTargetId={handleSelectTargetId}
                      onPlanEva={() => handlePlanEva()}
                      isPlanning={isPlanning}
                    />
                  ) : (
                    <LayerManagerPanel
                      layers={layers}
                      onToggleLayer={handleToggleLayer}
                      onChangeOpacity={handleChangeOpacity}
                      onOpenProvenance={inst => {
                        setProvenanceFilter(inst);
                        setIsProvenanceOpen(true);
                      }}
                    />
                  )}
                </div>
              </aside>
            )}

            {/* Left Panel Collapse Toggle Button */}
            <button
              onClick={() => setLeftPanelMode(m => (m === 'HIDDEN' ? 'SETUP' : 'HIDDEN'))}
              className="absolute left-0 top-1/2 -translate-y-1/2 z-30 bg-[#0a0f18] hover:bg-[#1e293b] border border-gray-700 text-gray-300 hover:text-white p-1 rounded-r shadow-xl transition cursor-pointer"
              title={leftPanelMode === 'HIDDEN' ? 'Expand Configuration Panel' : 'Collapse Panel'}
              style={{ left: leftPanelMode !== 'HIDDEN' ? '20rem' : '0' }}
            >
              {leftPanelMode !== 'HIDDEN' ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            </button>

            {/* CENTER: INTERACTIVE MARS MAP VIEWPORT */}
            <main className="flex-1 h-full relative overflow-hidden">
              <MarsMapCanvas
                layers={layers}
                routes={routes}
                selectedRoute={selectedRoute}
                scienceTargets={scienceTargets}
                hazardZones={hazardZones}
                startPoint={startPoint}
                targetPoint={targetPoint}
                astronautPos={currentAstronautPos}
                astronautTelemetry={astronautTelemetry}
                dustStormActive={dustStormActive}
                onSelectScienceTarget={target => setActiveScienceModalTarget(target)}
                onSetTargetPoint={pt => {
                  setTargetPoint(pt);
                  const plan = planEvaRoutes(startPoint, pt, profile);
                  setRoutes(plan.routes);
                  setSelectedRoute(plan.selectedRoute);
                }}
                onSetStartPoint={pt => {
                  setStartPoint(pt);
                  const plan = planEvaRoutes(pt, targetPoint, profile);
                  setRoutes(plan.routes);
                  setSelectedRoute(plan.selectedRoute);
                }}
              />
            </main>

            {/* Right Panel Collapse Toggle Button */}
            <button
              onClick={() => setRightPanelOpen(v => !v)}
              className="absolute right-0 top-1/2 -translate-y-1/2 z-30 bg-[#0a0f18] hover:bg-[#1e293b] border border-gray-700 text-gray-300 hover:text-white p-1 rounded-l shadow-xl transition cursor-pointer"
              title={rightPanelOpen ? 'Collapse Route Panel' : 'Expand Route Panel'}
              style={{ right: rightPanelOpen ? '22rem' : '0' }}
            >
              {rightPanelOpen ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
            </button>

            {/* RIGHT DOCKED PANEL: ROUTE METRICS & "WHY THIS ROUTE?" */}
            {rightPanelOpen && (
              <aside className="w-[22rem] h-full flex flex-col z-20 shrink-0 shadow-2xl">
                <RoutePanel
                  routes={routes}
                  selectedRoute={selectedRoute}
                  onSelectRoute={r => setSelectedRoute(r)}
                />
              </aside>
            )}
          </div>

          {/* 3. BOTTOM EVA SIMULATOR & TELEMETRY CONTROLS */}
          <SimulatorControls
            isPlaying={isPlaying}
            onTogglePlay={() => setIsPlaying(p => !p)}
            onReset={() => {
              setIsPlaying(false);
              setCurrentElapsedSec(0);
              setDustStormActive(false);
              setActiveAlert(null);
              alertTriggeredRef.current = false;
              setEnvironment(INITIAL_ENVIRONMENTAL_CONDITIONS);
            }}
            playbackSpeed={playbackSpeed}
            onChangeSpeed={s => setPlaybackSpeed(s)}
            currentElapsedSec={currentElapsedSec}
            totalDurationSec={totalDurationSec}
            onSeekSec={sec => setCurrentElapsedSec(sec)}
            environment={environment}
            astronautTelemetry={astronautTelemetry}
            activeAlert={activeAlert}
            onTriggerReplanning={handleTriggerReplanning}
            onDismissAlert={() => setActiveAlert(a => (a ? { ...a, resolved: true } : null))}
            nearbyScienceTarget={nearbyScienceTarget}
            onPerformScienceObservation={target => {
              setScienceDecisionTarget(target);
            }}
            isPerformingObservation={isPerformingObservation}
          />
        </>
      )}

      {/* 4. MODALS & DRAWERS */}
      {/* Science Target Inspector Modal */}
      <ScienceTargetModal
        target={activeScienceModalTarget}
        onClose={() => setActiveScienceModalTarget(null)}
        onSetAsPrimaryTarget={target => {
          setSelectedTargetId(target.id);
          setTargetPoint([target.x, target.y]);
          const plan = planEvaRoutes(startPoint, [target.x, target.y], profile);
          setRoutes(plan.routes);
          setSelectedRoute(plan.selectedRoute);
        }}
        isPrimaryTarget={activeScienceModalTarget?.id === selectedTargetId}
      />

      {/* "WHAT IF?" Scenario Contingency Modal */}
      <WhatIfModal
        isOpen={isWhatIfModalOpen}
        onClose={() => setIsWhatIfModalOpen(false)}
        originalRoute={selectedRoute}
        onApplyScenario={handleApplyWhatIfScenario}
        onSimulateScenario={handleSimulateScenario}
      />

      {/* AI Mission Copilot Drawer */}
      <MissionCopilot
        isOpen={isCopilotOpen}
        onClose={() => setIsCopilotOpen(false)}
        selectedRoute={selectedRoute}
        profile={profile}
        environment={environment}
        astronautTelemetry={astronautTelemetry}
        scienceTargets={scienceTargets}
      />

      {/* NASA Data Provenance Drawer */}
      <DataProvenanceDrawer
        isOpen={isProvenanceOpen}
        onClose={() => setIsProvenanceOpen(false)}
        selectedInstrumentFilter={provenanceFilter}
      />

      {/* Post-EVA Debrief Report Modal */}
      <MissionReportModal
        isOpen={isReportOpen}
        onClose={() => setIsReportOpen(false)}
        selectedRoute={selectedRoute}
        profile={profile}
        environment={environment}
        astronautTelemetry={astronautTelemetry}
        scienceTargets={scienceTargets}
        onRestartMission={() => {
          setIsPlaying(false);
          setCurrentElapsedSec(0);
          setDustStormActive(false);
          setActiveAlert(null);
          alertTriggeredRef.current = false;
          setEnvironment(INITIAL_ENVIRONMENTAL_CONDITIONS);
          setCompletedObservations([]);
          setSamplesCollected([]);
        }}
      />

      {/* Flight Readiness Review / Pre-EVA Mission Briefing Modal */}
      <MissionBriefingModal
        isOpen={isBriefingOpen}
        onClose={() => setIsBriefingOpen(false)}
        onBeginMission={() => {
          setIsBriefingOpen(false);
          setCurrentPage('SIMULATOR');
          setIsPlaying(true);
        }}
        profile={profile}
      />

      {/* In-Situ Science Decision Modal */}
      <ScienceDecisionModal
        isOpen={!!scienceDecisionTarget}
        target={scienceDecisionTarget}
        onClose={() => setScienceDecisionTarget(null)}
        onSelectAction={action => {
          if (scienceDecisionTarget) {
            setCompletedObservations(prev =>
              prev.includes(scienceDecisionTarget.id) ? prev : [...prev, scienceDecisionTarget.id]
            );
            setSamplesCollected(prev => {
              const item = `${scienceDecisionTarget.id}: ${scienceDecisionTarget.name} (${action.name})`;
              return prev.includes(item) ? prev : [...prev, item];
            });
          }
          setScienceDecisionTarget(null);
        }}
        remainingTimeMin={astronautTelemetry.timeRemainingMin}
        batteryPct={astronautTelemetry.suitBatteryRemainingPct}
      />

      {/* Jury Demo Tour Walkthrough Modal */}
      <JuryTourModal
        isOpen={isJuryTourOpen}
        onClose={() => setIsJuryTourOpen(false)}
        onTriggerPlanEva={() => handlePlanEva()}
        onSelectScienceObjective={obj => setProfile(p => ({ ...p, objective: obj }))}
        onToggleLayer={handleToggleLayer}
        onTriggerDustScenario={() => {
          setDustStormActive(true);
          setEnvironment(e => ({ ...e, dustOpticalDepthTau: 1.88, windSpeedMs: 14.6 }));
          setActiveAlert({
            id: 'ALERT_DUST_DEMO',
            type: 'DUST_STORM_SURGE',
            title: '⚠ DUST STORM SURGE DETECTED (MARCI / MCS)',
            message: 'Atmospheric optical depth surged to tau = 1.88. Regolith slip hazard escalated on steep crater rims.',
            severity: 'CRITICAL',
            triggerAtElapsedSec: currentElapsedSec,
            impactTimeDeltaMin: 18,
            impactRiskDeltaPct: 35,
            suggestedAction: 'Reroute onto firm low-gradient bedrock bench to preserve traction.',
            resolved: false
          });
        }}
        onTriggerReplanning={handleTriggerReplanning}
        onOpenReport={() => setIsReportOpen(true)}
        onOpenProvenance={() => {
          setProvenanceFilter('');
          setIsProvenanceOpen(true);
        }}
      />

      {/* GitHub Pages Deployment & Hosting Modal */}
      <GithubPagesModal
        isOpen={isGithubPagesOpen}
        onClose={() => setIsGithubPagesOpen(false)}
      />
    </div>
  );
}
