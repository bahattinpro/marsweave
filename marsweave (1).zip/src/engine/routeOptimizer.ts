/**
 * MARSWEAVE — Multi-Objective EVA Route Optimizer
 * Implements weighted multi-objective A* pathfinding on Martian terrain grids.
 * Synthesizes terrain slope, boulder hazards, subsurface ice value, mineral spectra,
 * communication line-of-sight, and radiation exposure into an explainable operational plan.
 */

import {
  MissionProfile,
  RouteCandidate,
  RouteWaypoint,
  ScienceTarget,
  RouteComparisonDelta,
  HazardZone
} from '../types/marsweave';
import {
  GRID_COLS,
  GRID_ROWS,
  MISSION_BOUNDS,
  ARCADIA_ELEVATION_GRID,
  ARCADIA_SLOPE_GRID,
  ARCADIA_HAZARD_GRID,
  ARCADIA_ICE_GRID,
  ARCADIA_COMMS_GRID,
  ARCADIA_SCIENCE_TARGETS,
  ARCADIA_HAZARD_ZONES
} from '../data/arcadiaData';

interface GridNode {
  c: number; // 0..GRID_COLS-1
  r: number; // 0..GRID_ROWS-1
}

interface CostWeights {
  distanceWeight: number;
  slopeWeight: number;
  hazardWeight: number;
  scienceAttraction: number;
  iceAttraction: number;
  commsPenalty: number;
  maxSlopeAllowed: number;
}

/**
 * Derives cost weights dynamically from mission objective and risk tolerance.
 */
function getCostWeights(profile: MissionProfile, dustFactor: number = 1.0): CostWeights {
  let distanceWeight = 1.0;
  let slopeWeight = 2.4;
  let hazardWeight = 3.0;
  let scienceAttraction = 1.8;
  let iceAttraction = 1.5;
  let commsPenalty = 1.6;
  let maxSlopeAllowed = 25.0; // astronaut physical suit locomotion limit

  // Adjust for risk tolerance
  if (profile.riskTolerance === 'LOW') {
    slopeWeight *= 1.6;
    hazardWeight *= 1.8;
    maxSlopeAllowed = 18.0;
  } else if (profile.riskTolerance === 'HIGH') {
    slopeWeight *= 0.7;
    hazardWeight *= 0.6;
    maxSlopeAllowed = 29.0;
  }

  // Adjust for mission objective
  switch (profile.objective) {
    case 'WATER':
      iceAttraction *= 3.0;
      scienceAttraction *= 1.5;
      break;
    case 'MINERALOGY':
      scienceAttraction *= 2.8;
      iceAttraction *= 1.2;
      break;
    case 'GEOLOGY':
      scienceAttraction *= 2.4;
      slopeWeight *= 0.9; // Geologists tolerate steeper outcrop margins
      break;
    case 'TERRAIN_SURVEY':
      hazardWeight *= 1.4;
      distanceWeight *= 0.8;
      break;
    case 'MULTI_SCIENCE':
      scienceAttraction *= 2.2;
      iceAttraction *= 2.0;
      break;
  }

  // Communication priority modifier
  if (profile.commsPriority === 'HIGH') {
    commsPenalty *= 2.5;
  }

  // Dust storm modifier: dust friction increases risk and slope slip hazard
  hazardWeight *= dustFactor;
  slopeWeight *= Math.sqrt(dustFactor);

  return {
    distanceWeight,
    slopeWeight,
    hazardWeight,
    scienceAttraction,
    iceAttraction,
    commsPenalty,
    maxSlopeAllowed
  };
}

/**
 * Grid coordinates to Martian geographic Lat/Lon
 */
export function gridToCoordinates(x: number, y: number): { lat: number; lon: number } {
  const normX = Math.max(0, Math.min(100, x)) / 100;
  const normY = Math.max(0, Math.min(100, y)) / 100;
  const lat = MISSION_BOUNDS.minLat + (1 - normY) * (MISSION_BOUNDS.maxLat - MISSION_BOUNDS.minLat);
  const lon = MISSION_BOUNDS.minLon + normX * (MISSION_BOUNDS.maxLon - MISSION_BOUNDS.minLon);
  return {
    lat: Math.round(lat * 10000) / 10000,
    lon: Math.round(lon * 10000) / 10000
  };
}

/**
 * Finds science targets within a given radius of a grid waypoint.
 */
function findNearbyScienceTarget(x: number, y: number, radiusGrid: number = 8): ScienceTarget | undefined {
  return ARCADIA_SCIENCE_TARGETS.find(target => {
    const dist = Math.hypot(target.x - x, target.y - y);
    return dist <= radiusGrid;
  });
}

/**
 * Multi-objective A* algorithm finding optimal route on discrete grid.
 */
function runAStar(
  startGrid: GridNode,
  goalGrid: GridNode,
  weights: CostWeights,
  waypointBiases: GridNode[] = []
): GridNode[] {
  const cols = GRID_COLS;
  const rows = GRID_ROWS;

  const gScore = Array.from({ length: rows }, () => Array(cols).fill(Infinity));
  const fScore = Array.from({ length: rows }, () => Array(cols).fill(Infinity));
  const cameFrom = new Map<string, GridNode>();

  const openSet: GridNode[] = [startGrid];
  gScore[startGrid.r][startGrid.c] = 0;

  function heuristic(node: GridNode): number {
    const dx = node.c - goalGrid.c;
    const dy = node.r - goalGrid.r;
    let baseH = Math.hypot(dx, dy);

    // If waypoint bias exists (e.g. for Route B intermediate science targets)
    if (waypointBiases.length > 0) {
      let minBiasDist = Infinity;
      for (const wp of waypointBiases) {
        const d = Math.hypot(node.c - wp.c, node.r - wp.r);
        if (d < minBiasDist) minBiasDist = d;
      }
      baseH += minBiasDist * 0.4;
    }

    return baseH;
  }

  fScore[startGrid.r][startGrid.c] = heuristic(startGrid);

  const neighbors = [
    { dc: 1, dr: 0, cost: 1.0 },
    { dc: -1, dr: 0, cost: 1.0 },
    { dc: 0, dr: 1, cost: 1.0 },
    { dc: 0, dr: -1, cost: 1.0 },
    { dc: 1, dr: 1, cost: 1.414 },
    { dc: -1, dr: 1, cost: 1.414 },
    { dc: 1, dr: -1, cost: 1.414 },
    { dc: -1, dr: -1, cost: 1.414 }
  ];

  let iterations = 0;
  const maxIterations = 3500;

  while (openSet.length > 0 && iterations < maxIterations) {
    iterations++;

    // Find node with lowest fScore
    let lowestIdx = 0;
    for (let i = 1; i < openSet.length; i++) {
      const node = openSet[i];
      const lowestNode = openSet[lowestIdx];
      if (fScore[node.r][node.c] < fScore[lowestNode.r][lowestNode.c]) {
        lowestIdx = i;
      }
    }

    const current = openSet.splice(lowestIdx, 1)[0];

    if (current.c === goalGrid.c && current.r === goalGrid.r) {
      // Reconstruct path
      const path: GridNode[] = [current];
      let currKey = `${current.c},${current.r}`;
      while (cameFrom.has(currKey)) {
        const prev = cameFrom.get(currKey)!;
        path.unshift(prev);
        currKey = `${prev.c},${prev.r}`;
      }
      return path;
    }

    for (const nb of neighbors) {
      const nc = current.c + nb.dc;
      const nr = current.r + nb.dr;

      if (nc < 0 || nc >= cols || nr < 0 || nr >= rows) continue;

      const slope = ARCADIA_SLOPE_GRID[nr][nc];
      // Hard avoidance if slope exceeds max physical traction limit
      if (slope > weights.maxSlopeAllowed) continue;

      const hazard = ARCADIA_HAZARD_GRID[nr][nc];
      const iceConfidence = ARCADIA_ICE_GRID[nr][nc];
      const commsCoverage = ARCADIA_COMMS_GRID[nr][nc];

      // Multi-objective cell step cost
      let stepCost = nb.cost * weights.distanceWeight;

      // Exponential penalty for steep slopes
      if (slope > 14) {
        stepCost += Math.pow((slope - 14) / 4, 1.8) * weights.slopeWeight;
      }

      // Boulder & terrain obstacle penalty
      stepCost += hazard * 8.0 * weights.hazardWeight;

      // Communication shadow penalty
      if (commsCoverage < 75) {
        stepCost += ((75 - commsCoverage) / 25) * 4.0 * weights.commsPenalty;
      }

      // Science & ice attraction (negative cost / bonus)
      const normX = (nc / cols) * 100;
      const normY = (nr / rows) * 100;
      const nearTarget = findNearbyScienceTarget(normX, normY, 6);
      if (nearTarget) {
        stepCost = Math.max(0.2, stepCost - (nearTarget.scientificValue / 100) * weights.scienceAttraction);
      }

      // Subsurface ice proximity reward
      if (iceConfidence > 65) {
        stepCost = Math.max(0.3, stepCost - ((iceConfidence - 65) / 35) * weights.iceAttraction);
      }

      const tentativeG = gScore[current.r][current.c] + stepCost;

      if (tentativeG < gScore[nr][nc]) {
        cameFrom.set(`${nc},${nr}`, current);
        gScore[nr][nc] = tentativeG;
        fScore[nr][nc] = tentativeG + heuristic({ c: nc, r: nr });

        if (!openSet.some(n => n.c === nc && n.r === nr)) {
          openSet.push({ c: nc, r: nr });
        }
      }
    }
  }

  // Fallback direct line if graph search exhausted
  return [startGrid, goalGrid];
}

/**
 * Converts raw grid nodes into smooth operational waypoints with telemetry metrics.
 */
function buildWaypointsFromGrid(
  nodes: GridNode[],
  astronautSpeedMpm: number = 42
): RouteWaypoint[] {
  const cellMeters = (MISSION_BOUNDS.areaWidthKm * 1000) / GRID_COLS; // ~136 meters per cell
  const waypoints: RouteWaypoint[] = [];

  // Downsample nodes so we don't have 40 waypoints, but a clean 8-14 operational leg segments
  const step = Math.max(1, Math.floor(nodes.length / 10));
  const sampledNodes: GridNode[] = [];
  for (let i = 0; i < nodes.length; i += step) {
    sampledNodes.push(nodes[i]);
  }
  if (sampledNodes[sampledNodes.length - 1] !== nodes[nodes.length - 1]) {
    sampledNodes.push(nodes[nodes.length - 1]);
  }

  let cumulativeDist = 0;
  let cumulativeTime = 0;

  for (let i = 0; i < sampledNodes.length; i++) {
    const node = sampledNodes[i];
    const x = Math.round((node.c / GRID_COLS) * 100);
    const y = Math.round((node.r / GRID_ROWS) * 100);
    const coords = gridToCoordinates(x, y);

    const elev = ARCADIA_ELEVATION_GRID[node.r][node.c];
    const slope = ARCADIA_SLOPE_GRID[node.r][node.c];
    const hazard = ARCADIA_HAZARD_GRID[node.r][node.c];
    const comms = ARCADIA_COMMS_GRID[node.r][node.c];

    let legDist = 0;
    if (i > 0) {
      const prev = sampledNodes[i - 1];
      const dc = (node.c - prev.c) * cellMeters;
      const dr = (node.r - prev.r) * cellMeters;
      legDist = Math.hypot(dc, dr);
    }

    cumulativeDist += legDist;

    // Walking speed reduced on slope (Tobler's hiking function adjusted for Mars 0.38g)
    const slopePenaltyFactor = Math.max(0.4, 1 - (slope / 35));
    const effectiveSpeed = astronautSpeedMpm * slopePenaltyFactor;
    const legTime = legDist > 0 ? (legDist / effectiveSpeed) : 0;
    cumulativeTime += legTime;

    const nearScience = findNearbyScienceTarget(x, y, 7);

    waypoints.push({
      id: `WP-${String(i).padStart(2, '0')}`,
      label: i === 0 ? 'START' : i === sampledNodes.length - 1 ? 'TARGET' : `WP-${String(i).padStart(2, '0')}`,
      lat: coords.lat,
      lon: coords.lon,
      x,
      y,
      elevation: elev,
      slopeDeg: slope,
      hazardScore: hazard,
      commsSignalPct: comms,
      distanceFromPrevMeters: Math.round(legDist),
      cumulativeDistanceMeters: Math.round(cumulativeDist),
      cumulativeTimeMin: Math.round(cumulativeTime * 10) / 10,
      scienceTargetNear: nearScience
    });
  }

  return waypoints;
}

/**
 * Calculates complete RouteCandidate object with explainability metrics.
 */
function evaluateRouteCandidate(
  id: 'ROUTE_A' | 'ROUTE_B' | 'ROUTE_C',
  name: string,
  subtitle: string,
  description: string,
  color: string,
  waypoints: RouteWaypoint[],
  profile: MissionProfile,
  allHazards: HazardZone[]
): RouteCandidate {
  const totalDistanceKm = Math.round((waypoints[waypoints.length - 1].cumulativeDistanceMeters / 1000) * 100) / 100;
  
  // Base walking duration + extra time for visited science targets
  let totalScienceObservationMin = 0;
  const visitedTargets: ScienceTarget[] = [];
  const targetIdSet = new Set<string>();

  for (const wp of waypoints) {
    if (wp.scienceTargetNear && !targetIdSet.has(wp.scienceTargetNear.id)) {
      targetIdSet.add(wp.scienceTargetNear.id);
      visitedTargets.push(wp.scienceTargetNear);
      totalScienceObservationMin += wp.scienceTargetNear.observationTimeMin;
    }
  }

  const travelDurationMin = waypoints[waypoints.length - 1].cumulativeTimeMin;
  const totalDurationMin = Math.round((travelDurationMin + totalScienceObservationMin) * 10) / 10;

  // Slope and hazard averages
  const slopeSum = waypoints.reduce((acc, wp) => acc + wp.slopeDeg, 0);
  const avgSlopeDeg = Math.round((slopeSum / waypoints.length) * 10) / 10;
  const maxSlopeDeg = Math.max(...waypoints.map(wp => wp.slopeDeg));

  const hazardSum = waypoints.reduce((acc, wp) => acc + wp.hazardScore, 0);
  const hazardExposureScore = Math.round((hazardSum / waypoints.length) * 100);

  const commsSum = waypoints.reduce((acc, wp) => acc + wp.commsSignalPct, 0);
  const commsCoveragePct = Math.round(commsSum / waypoints.length);

  const totalScienceScore = visitedTargets.reduce((acc, t) => acc + t.scientificValue, 0);

  // Energy & O2 budgets
  const energyConsumptionPct = Math.min(100, Math.round((totalDurationMin / profile.durationMin) * 78));
  const suitOxygenUsedPct = Math.min(100, Math.round((totalDurationMin / profile.durationMin) * 65));

  // Determine which specific hazards were avoided
  const hazardsAvoided: string[] = [];
  for (const hz of allHazards) {
    const isNearby = waypoints.some(wp => Math.hypot(wp.x - hz.center[0], wp.y - hz.center[1]) < hz.radius + 6);
    if (!isNearby) {
      hazardsAvoided.push(`Avoided ${hz.name} (${hz.severity})`);
    }
  }

  // Dynamic explainable reasons
  const whyChosenReasons: string[] = [];
  if (id === 'ROUTE_A') {
    whyChosenReasons.push(`Maintains low slope profile (Avg: ${avgSlopeDeg}°, Max: ${maxSlopeDeg}°)`);
    whyChosenReasons.push(`Reliable communication link (${commsCoveragePct}% average orbiter signal)`);
    whyChosenReasons.push(`Intercepts ${visitedTargets.length} prime science targets along traverse`);
    whyChosenReasons.push(`Leaves ${Math.max(0, Math.round(profile.durationMin - totalDurationMin))} min safety margin in EVA time budget`);
  } else if (id === 'ROUTE_B') {
    whyChosenReasons.push(`Maximizes scientific sampling yield (${visitedTargets.length} targets visited, score: ${totalScienceScore})`);
    whyChosenReasons.push(`Extends route over high-probability subsurface ice deposits (SHARAD)`);
    whyChosenReasons.push(`Permits in-situ mineralogical core sampling at multiple stratigraphic benches`);
  } else {
    whyChosenReasons.push(`Shortest geometrical surface distance (${totalDistanceKm} km)`);
    whyChosenReasons.push(`Fastest transit time (${totalDurationMin} min)`);
    whyChosenReasons.push(`Direct line retreat path in case of life support contingency`);
  }

  return {
    id,
    name,
    subtitle,
    description,
    waypoints,
    totalDistanceKm,
    totalDurationMin,
    avgSlopeDeg,
    maxSlopeDeg,
    hazardExposureScore,
    commsCoveragePct,
    scienceTargetsVisited: visitedTargets,
    totalScienceScore,
    energyConsumptionPct,
    suitOxygenUsedPct,
    whyChosenReasons,
    hazardsAvoided,
    color
  };
}

/**
 * Computes all 3 candidate routes for the active mission setup.
 */
export function planEvaRoutes(
  startGridPos: [number, number], // [x, y] 0..100
  targetGridPos: [number, number], // [x, y] 0..100
  profile: MissionProfile,
  dustModifier: number = 1.0,
  commsModifier: number = 1.0
): {
  selectedRoute: RouteCandidate;
  routes: RouteCandidate[];
  comparison?: RouteComparisonDelta;
} {
  const startNode: GridNode = {
    c: Math.min(GRID_COLS - 1, Math.max(0, Math.round((startGridPos[0] / 100) * GRID_COLS))),
    r: Math.min(GRID_ROWS - 1, Math.max(0, Math.round((startGridPos[1] / 100) * GRID_ROWS)))
  };

  const goalNode: GridNode = {
    c: Math.min(GRID_COLS - 1, Math.max(0, Math.round((targetGridPos[0] / 100) * GRID_COLS))),
    r: Math.min(GRID_ROWS - 1, Math.max(0, Math.round((targetGridPos[1] / 100) * GRID_ROWS)))
  };

  // 1. ROUTE A: Balanced "Science & Safety"
  const weightsA = getCostWeights(profile, dustModifier);
  weightsA.commsPenalty *= commsModifier;
  const nodesA = runAStar(startNode, goalNode, weightsA);
  const waypointsA = buildWaypointsFromGrid(nodesA, profile.astronautSpeedMpm);
  const routeA = evaluateRouteCandidate(
    'ROUTE_A',
    'Route Alpha',
    'Balanced Science & Safety (Recommended)',
    'Optimally negotiates terrain hazards, preserves communication relay corridor, and harvests key periglacial science targets.',
    '#38bdf8', // Cool cyan
    waypointsA,
    profile,
    ARCADIA_HAZARD_ZONES
  );

  // 2. ROUTE B: "Maximum Science Target Yield"
  // Guide A* through intermediate science waypoints (e.g. SCI-02 or SCI-04)
  const weightsB = getCostWeights(profile, dustModifier);
  weightsB.scienceAttraction *= 2.8;
  weightsB.iceAttraction *= 2.5;
  weightsB.slopeWeight *= 0.7; // More adventurous
  const intermediateTarget = ARCADIA_SCIENCE_TARGETS.find(t => t.id === 'SCI-02') || ARCADIA_SCIENCE_TARGETS[1];
  const biasNode: GridNode = {
    c: Math.round((intermediateTarget.x / 100) * GRID_COLS),
    r: Math.round((intermediateTarget.y / 100) * GRID_ROWS)
  };
  const nodesB = runAStar(startNode, goalNode, weightsB, [biasNode]);
  const waypointsB = buildWaypointsFromGrid(nodesB, profile.astronautSpeedMpm);
  const routeB = evaluateRouteCandidate(
    'ROUTE_B',
    'Route Beta',
    'Maximum Science Yield',
    'Wider scientific transect sampling volcanic stratigraphy and multiple permafrost polygon stations. Higher time expenditure.',
    '#a855f7', // Purple
    waypointsB,
    profile,
    ARCADIA_HAZARD_ZONES
  );

  // 3. ROUTE C: "Direct / High Risk"
  // Prioritizes pure distance minimization; disregards terrain slope & hazard penalties
  const weightsC: CostWeights = {
    distanceWeight: 4.0,
    slopeWeight: 0.4,
    hazardWeight: 0.3,
    scienceAttraction: 0.1,
    iceAttraction: 0.1,
    commsPenalty: 0.2,
    maxSlopeAllowed: 32.0 // Dangerous limit
  };
  const nodesC = runAStar(startNode, goalNode, weightsC);
  const waypointsC = buildWaypointsFromGrid(nodesC, profile.astronautSpeedMpm);
  const routeC = evaluateRouteCandidate(
    'ROUTE_C',
    'Route Gamma',
    'Direct Transit (High Hazard)',
    'Shortest distance trajectory, but traverses scree slopes near crater rim and suffers communication blackout.',
    '#ef4444', // Red
    waypointsC,
    profile,
    ARCADIA_HAZARD_ZONES
  );

  // Determine selected route based on user objective
  let selected = routeA;
  if (profile.objective === 'MULTI_SCIENCE' && profile.sciencePriority === 'HIGH') {
    selected = routeB;
  } else if (profile.riskTolerance === 'HIGH' && profile.durationMin < 75) {
    selected = routeC;
  }

  return {
    selectedRoute: selected,
    routes: [routeA, routeB, routeC]
  };
}

/**
 * Computes exact quantitative deltas when dynamic replanning occurs.
 */
export function calculateReplanningDelta(
  originalRoute: RouteCandidate,
  adaptedRoute: RouteCandidate
): RouteComparisonDelta {
  const distDelta = Math.round((adaptedRoute.totalDistanceKm - originalRoute.totalDistanceKm) * 100) / 100;
  const timeDelta = Math.round((adaptedRoute.totalDurationMin - originalRoute.totalDurationMin) * 10) / 10;
  
  const riskDelta = Math.round(
    ((adaptedRoute.hazardExposureScore - originalRoute.hazardExposureScore) / Math.max(1, originalRoute.hazardExposureScore)) * 100
  );

  const scienceDelta = Math.round(
    ((adaptedRoute.totalScienceScore - originalRoute.totalScienceScore) / Math.max(1, originalRoute.totalScienceScore)) * 100
  );

  const commsDelta = Math.round(
    adaptedRoute.commsCoveragePct - originalRoute.commsCoveragePct
  );

  const explanation: string[] = [
    `Adapted route steers ${Math.abs(distDelta)} km ${distDelta >= 0 ? 'longer' : 'shorter'} around oncoming environmental hazard.`,
    `Estimated transit time adjusted by ${timeDelta >= 0 ? `+${timeDelta}` : timeDelta} minutes.`,
    `Overall terrain hazard exposure ${riskDelta <= 0 ? `reduced by ${Math.abs(riskDelta)}%` : `increased by ${riskDelta}%`}.`,
    `Communication reliability ${commsDelta >= 0 ? `improved by +${commsDelta}%` : `decreased by ${Math.abs(commsDelta)}%`}.`
  ];

  return {
    originalRouteId: originalRoute.id,
    newRouteId: adaptedRoute.id,
    distanceDeltaKm: distDelta,
    timeDeltaMin: timeDelta,
    riskDeltaPct: riskDelta,
    scienceValueDeltaPct: scienceDelta,
    commsDeltaPct: commsDelta,
    explanation
  };
}
