/**
 * MARSWEAVE — Scientific Aerospace Mission Control Navigation Bar
 */

import React from 'react';
import {
  Compass,
  Sparkles,
  Bot,
  Database,
  FileText,
  Radio,
  PlayCircle,
  HelpCircle,
  BookOpen
} from 'lucide-react';

export type PageId =
  | 'HOME'
  | 'THE PROBLEM'
  | 'HOW IT WORKS'
  | 'NASA DATA'
  | 'SCIENCE'
  | 'SIMULATOR'
  | 'MISSION REPORT'
  | 'SOURCES';

interface HeaderBarProps {
  currentPage: PageId;
  onNavigate: (page: PageId) => void;
  onOpenWhatIf: () => void;
  onOpenCopilot: () => void;
  onOpenProvenance: () => void;
  onOpenReport: () => void;
  onStartDemoTour: () => void;
  onOpenBriefing: () => void;
  onOpenGithubPages?: () => void;
  currentSol: number;
  localSolarTime: string;
  dustTau: number;
  commsPct: number;
}

export const HeaderBar: React.FC<HeaderBarProps> = ({
  currentPage,
  onNavigate,
  onOpenWhatIf,
  onOpenCopilot,
  onOpenProvenance,
  onOpenReport,
  onStartDemoTour,
  onOpenBriefing,
  onOpenGithubPages,
  currentSol,
  localSolarTime,
  dustTau,
  commsPct
}) => {
  const navItems: PageId[] = [
    'HOME',
    'THE PROBLEM',
    'HOW IT WORKS',
    'NASA DATA',
    'SCIENCE',
    'SIMULATOR',
    'MISSION REPORT',
    'SOURCES'
  ];

  return (
    <header className="h-14 bg-[#0a0d13] hairline-b px-4 flex items-center justify-between select-none z-30 relative font-sans text-xs">
      {/* Brand Identity */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => onNavigate('HOME')}
          className="flex items-center gap-2.5 text-left cursor-pointer group"
        >
          <div className="w-7 h-7 rounded bg-[#c85a32] flex items-center justify-center text-white font-bold font-mono text-xs">
            MW
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold tracking-tight text-white font-sans text-sm group-hover:text-[#c85a32] transition">
                MARSWEAVE
              </span>
              <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-[#161a24] text-[#8b95a5] border border-[#202736]">
                EVA-04
              </span>
            </div>
            <div className="text-[10px] font-mono text-[#6b7788] hidden sm:block">
              HUMAN MARS MISSION PLANNER
            </div>
          </div>
        </button>
      </div>

      {/* Main Scientific Website Navigation Tabs */}
      <nav className="hidden xl:flex items-center gap-1 font-mono text-[11px]">
        {navItems.map(item => {
          const isActive = currentPage === item;
          return (
            <button
              key={item}
              onClick={() => onNavigate(item)}
              className={`px-3 py-1.5 rounded transition cursor-pointer ${
                isActive
                  ? 'bg-[#181d28] text-white font-semibold border border-[#262f40]'
                  : 'text-[#8b95a5] hover:text-white hover:bg-[#121620]'
              }`}
            >
              {item}
            </button>
          );
        })}
      </nav>

      {/* Right Quick Controls & Mission Telemetry */}
      <div className="flex items-center gap-2 font-mono text-xs">
        {/* Compact Sol status */}
        <div className="hidden md:flex items-center gap-2 px-2.5 py-1 rounded bg-[#0f131c] border border-[#1c2230] text-[11px] text-[#8b95a5]">
          <span>SOL {currentSol}</span>
          <span className="text-gray-600">•</span>
          <span className="text-[#3898b8]">MRO {commsPct}%</span>
        </div>

        {/* What-If Lab button */}
        <button
          onClick={onOpenWhatIf}
          className="px-2.5 py-1.5 bg-[#121620] hover:bg-[#1a202c] border border-[#1e2533] text-[#cdd3de] rounded text-[11px] flex items-center gap-1.5 transition cursor-pointer"
          title="Open What-If Scenario Analysis Lab"
        >
          <Sparkles className="w-3.5 h-3.5 text-[#d49938]" />
          <span className="hidden sm:inline">WHAT-IF LAB</span>
        </button>

        {/* Mission Assistant (formerly AI Copilot) */}
        <button
          onClick={onOpenCopilot}
          className="px-2.5 py-1.5 bg-[#121620] hover:bg-[#1a202c] border border-[#1e2533] text-[#cdd3de] rounded text-[11px] flex items-center gap-1.5 transition cursor-pointer"
          title="Open Flight Controller Mission Assistant"
        >
          <Bot className="w-3.5 h-3.5 text-[#3898b8]" />
          <span className="hidden sm:inline">ASSISTANT</span>
        </button>

        {/* Presentation Demo Flow */}
        <button
          onClick={onStartDemoTour}
          className="px-2.5 py-1.5 bg-[#181d28] hover:bg-[#202736] border border-[#c85a32]/50 text-[#c85a32] rounded text-[11px] flex items-center gap-1.5 transition cursor-pointer"
          title="2-minute Jury Presentation Flow"
        >
          <PlayCircle className="w-3.5 h-3.5 text-[#c85a32]" />
          <span>JURY TOUR</span>
        </button>

        {/* GitHub Pages Deployment Hub */}
        {onOpenGithubPages && (
          <button
            onClick={onOpenGithubPages}
            className="px-2.5 py-1.5 bg-[#151c27] hover:bg-[#1f2838] border border-[#2b394f] text-emerald-400 hover:text-emerald-300 rounded text-[11px] flex items-center gap-1.5 transition cursor-pointer font-semibold shadow-sm"
            title="GitHub Pages ile Yayınlama ve Dağıtım Rehberi"
          >
            <span className="text-sm">🐙</span>
            <span className="hidden sm:inline">GITHUB PAGES</span>
          </button>
        )}

        {/* Direct Link to Simulator if on other pages */}
        {currentPage !== 'SIMULATOR' && (
          <button
            onClick={() => onNavigate('SIMULATOR')}
            className="px-3 py-1.5 bg-[#c85a32] hover:bg-[#b54f2a] text-white rounded font-sans font-semibold text-xs transition cursor-pointer shadow-sm"
          >
            SIMULATOR →
          </button>
        )}
      </div>
    </header>
  );
};

