/**
 * MARSWEAVE — NASA Data Provenance & Archival Traceability Drawer
 */

import React, { useState } from 'react';
import { DataProvenanceEntry } from '../../types/marsweave';
import { NASA_PROVENANCE_REGISTRY } from '../../data/arcadiaData';
import {
  Database,
  X,
  ExternalLink,
  ShieldCheck,
  Search,
  Filter,
  Info
} from 'lucide-react';

interface DataProvenanceDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  selectedInstrumentFilter?: string;
}

export const DataProvenanceDrawer: React.FC<DataProvenanceDrawerProps> = ({
  isOpen,
  onClose,
  selectedInstrumentFilter
}) => {
  const [searchQuery, setSearchQuery] = useState<string>(selectedInstrumentFilter || '');

  if (!isOpen) return null;

  const filteredEntries = NASA_PROVENANCE_REGISTRY.filter(entry => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      entry.instrument.toLowerCase().includes(q) ||
      entry.instrumentFull.toLowerCase().includes(q) ||
      entry.mission.toLowerCase().includes(q) ||
      entry.usedInMarsweaveFor.toLowerCase().includes(q)
    );
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-end bg-black/75 backdrop-blur-sm select-none">
      <div className="bg-[#0b0f19] border-l border-[#1e293b] w-full max-w-2xl h-full shadow-2xl flex flex-col text-gray-200">
        {/* Header */}
        <div className="p-4 border-b border-[#1e293b] bg-[#0d1322] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-[#38bdf8]/15 text-[#38bdf8] rounded border border-[#38bdf8]/30">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <div className="text-[10px] font-mono text-[#38bdf8] uppercase tracking-widest font-semibold">
                SCIENTIFIC REPRODUCIBILITY & HONESTY
              </div>
              <h2 className="text-base font-heading font-bold text-white tracking-wide">
                NASA DATA PROVENANCE REGISTRY
              </h2>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white p-1.5 rounded hover:bg-[#1e293b] transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Bar */}
        <div className="p-3 border-b border-[#1e293b] bg-[#080c14] flex items-center gap-2">
          <Search className="w-4 h-4 text-gray-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search NASA instrument, mission, or dataset..."
            className="flex-1 bg-transparent text-xs text-white outline-none font-mono placeholder-gray-500"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="text-[10px] font-mono text-gray-400 hover:text-white"
            >
              CLEAR
            </button>
          )}
        </div>

        {/* Provenance Card List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3.5 text-xs">
          <div className="bg-[#0f172a] border border-[#1e293b] p-3 rounded text-[11px] text-gray-300 leading-relaxed">
            <span className="text-[#38bdf8] font-bold block mb-1 font-mono">SCIENTIFIC INTEGRITY STATEMENT:</span>
            MARSWEAVE utilizes verified NASA Planetary Data System (PDS) releases, published mission instruments, and calibrated engineering parameters. All datasets are classified transparently according to whether they originate from direct archival observations, calibrated models, or operational simulations.
          </div>

          {filteredEntries.map(entry => (
            <div
              key={entry.instrument}
              className="bg-[#0f172a] border border-[#1e293b] hover:border-gray-600 rounded p-3.5 transition space-y-2.5"
            >
              {/* Header Row */}
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-heading font-bold text-white">
                      {entry.instrument}
                    </span>
                    <span className="text-xs text-gray-400">
                      ({entry.instrumentFull})
                    </span>
                  </div>
                  <div className="text-[10px] font-mono text-[#38bdf8] mt-0.5">
                    {entry.mission} • {entry.agency}
                  </div>
                </div>

                <span
                  className={`text-[9px] font-mono px-2 py-0.5 rounded uppercase font-semibold shrink-0 ${
                    entry.dataStatus === 'REAL NASA ARCHIVE'
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-800/40'
                      : entry.dataStatus === 'DERIVED'
                      ? 'bg-sky-950 text-sky-300 border border-sky-800/40'
                      : entry.dataStatus === 'MODELLED'
                      ? 'bg-amber-950 text-amber-300 border border-amber-800/40'
                      : 'bg-purple-950 text-purple-300 border border-purple-800/40'
                  }`}
                >
                  {entry.dataStatus}
                </span>
              </div>

              {/* Data Specifications */}
              <div className="grid grid-cols-2 gap-2 text-[10.5px] font-mono bg-[#090d16] p-2 rounded border border-gray-800/70">
                <div>
                  <span className="text-gray-500 block">PDS IDENTIFIER:</span>
                  <span className="text-gray-300 truncate block">{entry.pdsDatasetId}</span>
                </div>
                <div>
                  <span className="text-gray-500 block">SPATIAL RESOLUTION:</span>
                  <span className="text-gray-300">{entry.spatialResolution}</span>
                </div>
                <div>
                  <span className="text-gray-500 block">SPECTRAL BANDWIDTH:</span>
                  <span className="text-gray-300 truncate block">{entry.spectralRange}</span>
                </div>
                <div>
                  <span className="text-gray-500 block">DATA CONFIDENCE:</span>
                  <span className={entry.confidence === 'HIGH' ? 'text-emerald-400 font-semibold' : 'text-amber-400 font-semibold'}>
                    {entry.confidence}
                  </span>
                </div>
              </div>

              {/* Role in Marsweave */}
              <div>
                <span className="text-[10px] font-mono uppercase tracking-wider text-gray-400 block mb-0.5">
                  ROLE IN MARSWEAVE OPTIMIZATION:
                </span>
                <p className="text-gray-300 text-[11px]">
                  {entry.usedInMarsweaveFor}
                </p>
              </div>

              {/* Scientific Honesty Notes */}
              <div className="pt-2 border-t border-gray-800">
                <span className="text-[10px] font-mono uppercase tracking-wider text-amber-400 font-semibold block mb-0.5">
                  METHODOLOGICAL CAVEAT & HONESTY:
                </span>
                <p className="text-gray-400 font-mono text-[10px] leading-relaxed">
                  {entry.scientificHonestyNotes}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-[#1e293b] bg-[#0d1322] flex items-center justify-between text-[10px] font-mono text-gray-500">
          <span>NASA Planetary Data System (PDS) Release 78 Referenced</span>
          <button
            onClick={onClose}
            className="px-3 py-1 bg-gray-800 hover:bg-gray-700 text-white rounded transition"
          >
            CLOSE
          </button>
        </div>
      </div>
    </div>
  );
};
