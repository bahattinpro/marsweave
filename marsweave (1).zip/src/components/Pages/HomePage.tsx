/**
 * MARSWEAVE — Home / Editorial Briefing View
 * Scientific editorial layout communicating exploration, precision, and engineering.
 */

import React from 'react';
import {
  Compass,
  ArrowRight,
  Database,
  Layers,
  Radio,
  Sparkles,
  Mountain,
  Shield,
  Activity,
  CheckCircle2,
  ExternalLink
} from 'lucide-react';

interface HomePageProps {
  onNavigate: (page: string) => void;
  onLaunchSimulator: () => void;
  onOpenGithubPages?: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  onNavigate,
  onLaunchSimulator,
  onOpenGithubPages
}) => {
  return (
    <div className="flex-1 overflow-y-auto bg-[#0b0d12] text-[#d6d9e0] select-text">
      {/* Top Telemetry Baseline Strip */}
      <div className="hairline-b bg-[#0e1117] px-6 py-2 flex flex-wrap items-center justify-between text-[11px] font-mono text-[#8b95a5]">
        <div className="flex items-center gap-6">
          <span>OPERATIONAL ZONE: <strong className="text-white">ARCADIA PLANITIA</strong> (39.3°N, 171.4°W)</span>
          <span className="hidden md:inline">ELEVATION DATUM: <strong className="text-white">-4,020 M</strong> (MOLA)</span>
          <span className="hidden lg:inline">ATMOSPHERE: <strong className="text-white">680 PA CO₂</strong> (MEDA)</span>
        </div>
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5 text-[#3898b8]">
            <span className="w-1.5 h-1.5 rounded-full bg-[#3898b8]" />
            MRO RELAY: ACTIVE
          </span>
          <span className="text-[#8b95a5]">NASA SPACE APPS 2026</span>
        </div>
      </div>

      {/* Hero Section */}
      <div className="max-w-6xl mx-auto px-6 py-16 md:py-24">
        <div className="max-w-3xl space-y-6">
          <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded bg-[#181d26] border border-[#222a38] text-[11px] font-mono text-[#c85a32]">
            <span>SYSTEM ARCHITECTURE</span>
            <span className="text-[#647082]">•</span>
            <span>HUMAN MARS SURFACE OPERATIONS</span>
          </div>

          <h1 className="text-4xl md:text-6xl font-sans font-bold tracking-tight text-white leading-[1.08]">
            Intelligent EVA Planning for the Red Planet.
          </h1>

          <p className="text-base md:text-lg text-[#9ba5b5] font-sans leading-relaxed">
            MARSWEAVE combines planetary observations, terrain slope analysis, subsurface radar echoes, mineralogical spectroscopy, and mission constraints into an explainable, multi-objective route planning system for human Marswalks.
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-3">
            <button
              onClick={onLaunchSimulator}
              className="px-5 py-2.5 bg-[#c85a32] hover:bg-[#b54f2a] text-white font-sans font-medium text-xs rounded transition flex items-center gap-2 cursor-pointer shadow-sm"
            >
              <span>ENTER MISSION SIMULATOR</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => onNavigate('THE PROBLEM')}
              className="px-4 py-2.5 bg-[#141822] hover:bg-[#1c2230] border border-[#222a38] text-[#cdd3de] font-sans text-xs rounded transition cursor-pointer"
            >
              THE PROBLEM WE SOLVE
            </button>
            <button
              onClick={() => onNavigate('HOW IT WORKS')}
              className="px-4 py-2.5 bg-[#141822] hover:bg-[#1c2230] border border-[#222a38] text-[#cdd3de] font-sans text-xs rounded transition cursor-pointer"
            >
              SYSTEM PIPELINE
            </button>
            {onOpenGithubPages && (
              <button
                onClick={onOpenGithubPages}
                className="px-4 py-2.5 bg-[#121c18] hover:bg-[#182822] border border-emerald-500/30 text-emerald-300 font-sans text-xs rounded transition cursor-pointer flex items-center gap-1.5 font-medium"
              >
                <span>🐙 GITHUB PAGES İLE YAYINLA</span>
              </button>
            )}
          </div>
        </div>

        {/* Technical Data Ribbon */}
        <div className="mt-16 hairline-t hairline-b py-6 grid grid-cols-2 md:grid-cols-4 gap-6 font-mono text-xs">
          <div>
            <div className="text-[10px] text-[#6b7788] uppercase tracking-wider mb-1">NASA DATASETS</div>
            <div className="text-lg font-semibold text-white">10 INSTRUMENTS</div>
            <div className="text-[11px] text-[#8b95a5] mt-0.5">MOLA, HiRISE, SHARAD, CRISM, MEDA</div>
          </div>
          <div>
            <div className="text-[10px] text-[#6b7788] uppercase tracking-wider mb-1">PATHFINDING MODEL</div>
            <div className="text-lg font-semibold text-white">MULTI-OBJECTIVE A*</div>
            <div className="text-[11px] text-[#8b95a5] mt-0.5">Slope, scree, comms, science yield</div>
          </div>
          <div>
            <div className="text-[10px] text-[#6b7788] uppercase tracking-wider mb-1">DEMONSTRATION AREA</div>
            <div className="text-lg font-semibold text-white">ARCADIA PLANITIA</div>
            <div className="text-[11px] text-[#8b95a5] mt-0.5">50 × 50 discrete surface matrix</div>
          </div>
          <div>
            <div className="text-[10px] text-[#6b7788] uppercase tracking-wider mb-1">DECISION INTEGRITY</div>
            <div className="text-lg font-semibold text-white">TRANSPARENT REASONING</div>
            <div className="text-[11px] text-[#8b95a5] mt-0.5">Quantitative "Why this route?" deltas</div>
          </div>
        </div>

        {/* The 6-Stage Operational Cycle */}
        <div className="mt-16 space-y-8">
          <div>
            <div className="text-[11px] font-mono text-[#c85a32] uppercase tracking-wider mb-1">OPERATIONAL CYCLE</div>
            <h2 className="text-2xl font-bold text-white tracking-tight">
              A Complete Planetary Exploration Workflow
            </h2>
            <p className="text-sm text-[#8b95a5] max-w-2xl mt-1">
              Human surface exploration is an iterative loop of remote observation, in-situ discovery, and continuous environmental adaptation.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-3">
            {[
              {
                step: '01',
                title: 'OBSERVE',
                desc: 'Ingest and georeference archival MOLA, HiRISE, SHARAD, and CRISM datasets onto a shared Martian datum.'
              },
              {
                step: '02',
                title: 'UNDERSTAND',
                desc: 'Extract physical properties: terrain steepness, boulder hazards, subsurface dielectric permittivity, and thermal inertia.'
              },
              {
                step: '03',
                title: 'PLAN',
                desc: 'Generate candidate routes balancing traverse distance, terrain risk, science reward, and life support margins.'
              },
              {
                step: '04',
                title: 'WALK',
                desc: 'Simulate astronaut movement with metabolic rate modeling, suit oxygen consumption, and orbital relay tracking.'
              },
              {
                step: '05',
                title: 'DISCOVER',
                desc: 'Execute protocolized in-situ observations at periglacial ice and phyllosilicate clay stratigraphic contacts.'
              },
              {
                step: '06',
                title: 'ADAPT',
                desc: 'Dynamically re-evaluate routes when atmospheric dust storms or orbital communication blackouts occur.'
              }
            ].map(item => (
              <div key={item.step} className="bg-[#10141d] border border-[#1c2230] p-4 flex flex-col justify-between">
                <div>
                  <span className="font-mono text-xs text-[#c85a32] font-semibold">{item.step}</span>
                  <h3 className="font-sans font-semibold text-sm text-white mt-1 mb-2">{item.title}</h3>
                  <p className="text-xs text-[#8b95a5] leading-relaxed">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Why Science-Driven Routing Matters */}
        <div className="mt-20 hairline-t pt-12 grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
          <div className="space-y-4">
            <span className="text-[11px] font-mono text-[#3898b8] uppercase tracking-wider block">MISSION SAFETY & DISCOVERY</span>
            <h2 className="text-2xl font-bold text-white tracking-tight">
              Why the shortest path is rarely the right mission path.
            </h2>
            <p className="text-sm text-[#9ba5b5] leading-relaxed">
              Standard geospatial routing minimizes geometric distance. On Mars, an unweighted straight line frequently cuts across 34° unstable impact crater scree, descends into topographic radar blindspots, or walks past critical water-ice deposits without stopping.
            </p>
            <p className="text-sm text-[#9ba5b5] leading-relaxed">
              MARSWEAVE weights each terrain step against physical safety constraints and scientific value, providing human planners with transparent trade-offs between rapid transit and scientific harvest.
            </p>
            <div className="pt-2">
              <button
                onClick={() => onNavigate('THE PROBLEM')}
                className="text-xs font-mono text-[#c85a32] hover:text-[#e06a3e] flex items-center gap-1.5 transition cursor-pointer"
              >
                <span>EXPLORE THE MULTI-VARIABLE PROBLEM</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <div className="bg-[#10141d] border border-[#1c2230] p-6 space-y-4 font-mono text-xs">
            <div className="flex items-center justify-between hairline-b pb-3">
              <span className="text-[#8b95a5]">ROUTE COMPARISON (ARCADIA-EVA-01)</span>
              <span className="text-[10px] text-[#3898b8]">DERIVED METRICS</span>
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="text-[#8b95a5]">Candidate</span>
                <span className="text-[#8b95a5]">Distance</span>
                <span className="text-[#8b95a5]">Hazard Score</span>
                <span className="text-[#8b95a5]">Science Value</span>
              </div>
              <div className="flex items-center justify-between hairline-t pt-2 text-[#cdd3de]">
                <span className="font-semibold text-[#3898b8]">Route Alpha (Balanced)</span>
                <span>4.72 km</span>
                <span className="text-[#3898b8]">14 / 100</span>
                <span className="text-white font-semibold">185 pts</span>
              </div>
              <div className="flex items-center justify-between text-[#9ba5b5]">
                <span className="font-semibold text-[#a855f7]">Route Beta (Max Science)</span>
                <span>5.18 km</span>
                <span>21 / 100</span>
                <span className="text-white font-semibold">271 pts</span>
              </div>
              <div className="flex items-center justify-between text-[#6b7788]">
                <span className="font-semibold text-[#c85a32]">Route Gamma (Direct Shortest)</span>
                <span>3.81 km</span>
                <span className="text-[#c85a32] font-semibold">58 / 100 (HIGH)</span>
                <span>0 pts</span>
              </div>
            </div>

            <div className="hairline-t pt-3 text-[11px] text-[#8b95a5] leading-relaxed">
              <strong className="text-white">Key Takeaway:</strong> Route Gamma saves 0.91 km of travel but exposes the crew to a 34° scree crater scarp and forfeits all mineralogical and ice sampling.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
