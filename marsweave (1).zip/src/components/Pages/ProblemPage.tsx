/**
 * MARSWEAVE — The Multi-Variable Problem View
 * Explains the physical and operational challenges of human Martian EVA navigation.
 */

import React, { useState } from 'react';
import {
  AlertTriangle,
  ArrowRight,
  Mountain,
  Radio,
  Sparkles,
  Zap,
  Clock,
  Shield,
  Layers,
  CheckCircle2,
  XCircle,
  HelpCircle
} from 'lucide-react';

interface ProblemPageProps {
  onLaunchSimulator: () => void;
}

export const ProblemPage: React.FC<ProblemPageProps> = ({ onLaunchSimulator }) => {
  const [selectedComparison, setSelectedComparison] = useState<'SHORTEST' | 'OPTIMIZED'>('OPTIMIZED');

  const variables = [
    {
      title: 'TERRAIN & SLOPE',
      instrument: 'MOLA (MGS) & HRSC (MEX)',
      problem: 'Pressurized suits heavily restrict human knee flexion. Slopes exceeding 15° cause significant regolith slippage; slopes exceeding 25° present unrecoverable tumble risks.',
      status: 'REAL NASA ARCHIVE'
    },
    {
      title: 'BOULDER HAZARDS',
      instrument: 'HiRISE (MRO)',
      problem: 'Impact ejecta creates metric and decametric boulder fields with sharp basalt fracture edges that tear suit fabric and block pedestrian navigation.',
      status: 'REAL NASA ARCHIVE'
    },
    {
      title: 'SUBSURFACE WATER ICE',
      instrument: 'SHARAD (MRO)',
      problem: 'Accessing shallow, pure water-ice requires navigating over permafrost polygon grounds without stumbling into scalloped sublimation pits.',
      status: 'REAL NASA ARCHIVE'
    },
    {
      title: 'MINERALOGICAL TARGETS',
      instrument: 'CRISM (MRO)',
      problem: 'Hydrated clays and sulfates are localized in narrow stratigraphic benches. Deviating by even 150 meters causes astronauts to bypass primary astrobiological evidence.',
      status: 'REAL NASA ARCHIVE'
    },
    {
      title: 'ORBITAL RELAY COMMUNICATIONS',
      instrument: 'Mars Relay Network (MRO, Odyssey, TGO)',
      problem: 'Deep craters create topographic radar shadows, cutting off voice, telemetry, and medical data downlink to the base habitat.',
      status: 'SIMULATED'
    },
    {
      title: 'ATMOSPHERIC DUST & VISIBILITY',
      instrument: 'MCS & MARCI (MRO) / MEDA (Perseverance)',
      problem: 'Diurnal dust opacity surges (tau > 1.2) obscure terrain landmarks, accelerate heat loss, and reduce solar cell recharging efficiency.',
      status: 'MODELLED'
    },
    {
      title: 'SURFACE RADIATION',
      instrument: 'RAD (MSL Curiosity)',
      problem: 'Galactic cosmic rays and secondary albedo neutrons deliver ~28 µSv/h. Traversal plans must maintain conservative duration limits to minimize cumulative exposure.',
      status: 'DERIVED'
    },
    {
      title: 'DATA UNCERTAINTY',
      instrument: 'Heterogeneous Fusion',
      problem: 'Not all terrain has 25 cm/px resolution. Route planning must explicitly flag areas where orbital coverage confidence is low.',
      status: 'MODELLED'
    }
  ];

  return (
    <div className="flex-1 overflow-y-auto bg-[#0b0d12] text-[#d6d9e0] select-text">
      {/* Top Breadcrumb */}
      <div className="hairline-b bg-[#0e1117] px-6 py-2.5 text-xs font-mono text-[#8b95a5]">
        <span>MARSWEAVE</span> <span className="text-gray-600">/</span> <span className="text-white">OPERATIONAL CHALLENGE</span>
      </div>

      <div className="max-w-5xl mx-auto px-6 py-12 md:py-16 space-y-12">
        {/* Title Header */}
        <div className="space-y-4 max-w-3xl">
          <div className="inline-block text-[11px] font-mono text-[#c85a32] uppercase tracking-wider">
            MISSION PLANNING COMPLEXITY
          </div>
          <h1 className="text-3xl md:text-5xl font-sans font-bold tracking-tight text-white leading-tight">
            Planning a Human Marswalk is a Multi-Variable Problem.
          </h1>
          <p className="text-sm md:text-base text-[#9ba5b5] font-sans leading-relaxed">
            On Earth, navigation algorithms simply optimize for travel time or distance. On Mars, an unweighted straight line between Habitat Alpha and a science target can be dangerous and scientifically unproductive.
          </p>
        </div>

        {/* Interactive Comparison Widget */}
        <div className="bg-[#10141d] border border-[#1c2230] p-6 space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4 hairline-b pb-4">
            <div>
              <h2 className="text-base font-bold text-white font-sans">
                Comparative Route Assessment: Arcadia Planitia
              </h2>
              <p className="text-xs text-[#8b95a5] font-sans mt-0.5">
                Toggle below to evaluate why the shortest Euclidean path fails critical mission safety criteria.
              </p>
            </div>

            <div className="flex bg-[#0b0e14] border border-[#222a38] p-1 rounded font-mono text-xs">
              <button
                onClick={() => setSelectedComparison('SHORTEST')}
                className={`px-3 py-1.5 rounded transition ${
                  selectedComparison === 'SHORTEST'
                    ? 'bg-[#c85a32] text-white font-semibold'
                    : 'text-[#8b95a5] hover:text-white'
                }`}
              >
                SHORTEST ROUTE (DIRECT)
              </button>
              <button
                onClick={() => setSelectedComparison('OPTIMIZED')}
                className={`px-3 py-1.5 rounded transition ${
                  selectedComparison === 'OPTIMIZED'
                    ? 'bg-[#3898b8] text-white font-semibold'
                    : 'text-[#8b95a5] hover:text-white'
                }`}
              >
                MISSION-OPTIMIZED (MARSWEAVE)
              </button>
            </div>
          </div>

          {/* Metric Comparison Table */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 font-mono text-xs">
            <div className="bg-[#0b0e14] border border-[#1c2230] p-3">
              <span className="text-[10px] text-[#6b7788] block mb-1">TOTAL DISTANCE</span>
              <span className="text-base font-bold text-white">
                {selectedComparison === 'SHORTEST' ? '3.81 KM' : '4.72 KM'}
              </span>
              <span className="text-[10px] text-[#8b95a5] block mt-0.5">
                {selectedComparison === 'SHORTEST' ? 'Direct Euclidean line' : '+0.91 km detour around scarp'}
              </span>
            </div>

            <div className="bg-[#0b0e14] border border-[#1c2230] p-3">
              <span className="text-[10px] text-[#6b7788] block mb-1">MAX SLOPE ANGLE</span>
              <span className={`text-base font-bold ${selectedComparison === 'SHORTEST' ? 'text-[#c85a32]' : 'text-[#3898b8]'}`}>
                {selectedComparison === 'SHORTEST' ? '34.2° (UNSTABLE)' : '14.2° (TRAVERSABLE)'}
              </span>
              <span className="text-[10px] text-[#8b95a5] block mt-0.5">
                {selectedComparison === 'SHORTEST' ? 'Exceeds suit 25° limit' : 'Within nominal suit traction'}
              </span>
            </div>

            <div className="bg-[#0b0e14] border border-[#1c2230] p-3">
              <span className="text-[10px] text-[#6b7788] block mb-1">COMMS RELAY COVERAGE</span>
              <span className={`text-base font-bold ${selectedComparison === 'SHORTEST' ? 'text-[#c85a32]' : 'text-[#3898b8]'}`}>
                {selectedComparison === 'SHORTEST' ? '71% (BLINDSPOTS)' : '94% (CONTINUOUS)'}
              </span>
              <span className="text-[10px] text-[#8b95a5] block mt-0.5">
                {selectedComparison === 'SHORTEST' ? 'Crater floor shadow' : 'Preserves MRO line-of-sight'}
              </span>
            </div>

            <div className="bg-[#0b0e14] border border-[#1c2230] p-3">
              <span className="text-[10px] text-[#6b7788] block mb-1">SCIENCE HARVEST</span>
              <span className={`text-base font-bold ${selectedComparison === 'SHORTEST' ? 'text-[#6b7788]' : 'text-emerald-400'}`}>
                {selectedComparison === 'SHORTEST' ? '0 SAMPLES (0 PTS)' : '2 TARGETS (185 PTS)'}
              </span>
              <span className="text-[10px] text-[#8b95a5] block mt-0.5">
                {selectedComparison === 'SHORTEST' ? 'Bypasses clay deposit' : 'Intercepts SCI-04 and SCI-07'}
              </span>
            </div>
          </div>

          {/* Qualitative Operational Assessment */}
          <div className="bg-[#0b0e14] border border-[#1c2230] p-4 text-xs font-sans space-y-2">
            <span className="font-mono text-[10px] text-[#8b95a5] uppercase tracking-wider block">
              OPERATIONAL FLIGHT CONTROLLER ANALYSIS
            </span>
            {selectedComparison === 'SHORTEST' ? (
              <div className="space-y-1.5 text-[#b0b8c6]">
                <p className="flex items-start gap-2">
                  <XCircle className="w-4 h-4 text-[#c85a32] shrink-0 mt-0.5" />
                  <span><strong>Crater Scarp Violation:</strong> The route traverses the southern rim of Arcadia-C1 with a 34° slope gradient. Under Martian gravity (0.38g), fine basalt scree lacks shear strength, presenting a severe tumble risk.</span>
                </p>
                <p className="flex items-start gap-2">
                  <XCircle className="w-4 h-4 text-[#c85a32] shrink-0 mt-0.5" />
                  <span><strong>Communication Loss:</strong> The astronaut enters a deep topographic depression between km 1.8 and 2.6, resulting in complete UHF signal loss from the orbiting MRO relay.</span>
                </p>
                <p className="flex items-start gap-2">
                  <XCircle className="w-4 h-4 text-[#c85a32] shrink-0 mt-0.5" />
                  <span><strong>Science Forfeit:</strong> Bypasses Target SCI-04 (SHARAD subsurface ice contact) by 240 meters, forfeiting the primary ISRU prospecting opportunity of the EVA.</span>
                </p>
              </div>
            ) : (
              <div className="space-y-1.5 text-[#b0b8c6]">
                <p className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#3898b8] shrink-0 mt-0.5" />
                  <span><strong>Safe Gradient Envelope:</strong> Negotiates a gentle bench gradient with a maximum slope of 14.2°, well below the pressurized EVA suit limit.</span>
                </p>
                <p className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#3898b8] shrink-0 mt-0.5" />
                  <span><strong>Continuous Link:</strong> Retains high line-of-sight elevation angles to MRO and Habitat Alpha, ensuring real-time biometric and telemetry streaming.</span>
                </p>
                <p className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#3898b8] shrink-0 mt-0.5" />
                  <span><strong>Maximum Scientific Return:</strong> Direct transect over Target SCI-04 (permafrost contraction cracks) and arrives at Target SCI-07 with 28 minutes of reserve life support time.</span>
                </p>
              </div>
            )}
          </div>
        </div>

        {/* The 8 Multi-Variable Dimensions */}
        <div className="space-y-6">
          <div className="hairline-b pb-2">
            <h2 className="text-xl font-bold text-white font-sans tracking-tight">
              The 8 Variables of Mars Surface Navigation
            </h2>
            <p className="text-xs text-[#8b95a5] font-sans mt-0.5">
              Each variable is derived from specific NASA orbital or in-situ instruments and integrated into our cost matrix.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {variables.map(item => (
              <div key={item.title} className="bg-[#10141d] border border-[#1c2230] p-4 space-y-2">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="font-semibold text-white">{item.title}</span>
                  <span className="text-[9px] px-1.5 py-0.5 rounded bg-[#181d26] text-[#8b95a5]">
                    {item.status}
                  </span>
                </div>
                <div className="text-[11px] font-mono text-[#3898b8]">
                  SOURCE: {item.instrument}
                </div>
                <p className="text-xs text-[#8b95a5] font-sans leading-relaxed">
                  {item.problem}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Scientific Honesty Disclaimer */}
        <div className="bg-[#141822] border border-[#222a38] p-5 space-y-2 text-xs font-sans text-[#8b95a5] leading-relaxed">
          <div className="flex items-center gap-2 text-white font-mono font-semibold">
            <HelpCircle className="w-4 h-4 text-[#c85a32]" />
            <span>METHODOLOGICAL HONESTY STATEMENT</span>
          </div>
          <p>
            MARSWEAVE is an aerospace mission-planning decision-support prototype. Traversal metrics represent <em>derived mission-planning estimates</em> and <em>modelled risk profiles</em>. They do not constitute certified NASA human life-support safety ratings. High-resolution terrain extrapolation relies on published MRO HiRISE and MGS MOLA archival datasets released through the NASA Planetary Data System.
          </p>
        </div>

        {/* Call to Action */}
        <div className="hairline-t pt-8 flex items-center justify-between">
          <span className="text-xs font-mono text-[#8b95a5]">Ready to test these variables in real time?</span>
          <button
            onClick={onLaunchSimulator}
            className="px-5 py-2.5 bg-[#c85a32] hover:bg-[#b54f2a] text-white font-sans font-medium text-xs rounded transition flex items-center gap-2 cursor-pointer shadow-sm"
          >
            <span>LAUNCH MISSION SIMULATOR</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
