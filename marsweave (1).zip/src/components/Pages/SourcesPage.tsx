/**
 * MARSWEAVE — Scientific Sources & Literature Citations View
 * Peer-reviewed planetary science papers and official NASA PDS archival references.
 */

import React from 'react';
import { Database, ExternalLink, BookOpen, FileCheck } from 'lucide-react';

export const SourcesPage: React.FC = () => {
  const citations = [
    {
      author: 'Bramson, A. M., Byrne, S., Putzig, N. E., Sutton, S., Plaut, J. J., Brothers, T. C., & Holt, J. W.',
      year: '2015',
      title: 'Widespread excess ice in Arcadia Planitia, Mars',
      journal: 'Geophysical Research Letters, 42(16), 6566-6574',
      doi: '10.1002/2015GL064844',
      note: 'Documents widespread, tens of meters thick excess subsurface water ice deposits in Arcadia Planitia using SHARAD dielectric modeling.'
    },
    {
      author: 'Stuurman, C. M., Osinski, G. R., Holt, J. W., Cadieux, S. B., Putzig, N. E., & Campbell, B. A.',
      year: '2016',
      title: 'SHARAD detection and mapping of subsurface water ice in Utopia and Arcadia Planitiae',
      journal: 'Geophysical Research Letters, 43(18), 9484-9491',
      doi: '10.1002/2016GL070138',
      note: 'Establishes shallow ice sheets with dielectric constant ε = 3.15, corresponding to >85% purity ice-rich permafrost within accessible drilling depths.'
    },
    {
      author: 'Ehlmann, B. L., & Edwards, C. S.',
      year: '2014',
      title: 'Mineralogy of the Martian Surface',
      journal: 'Annual Review of Earth and Planetary Sciences, 42, 291-315',
      doi: '10.1146/annurev-earth-060313-054614',
      note: 'Comprehensive catalog of phyllosilicates, hydrated silica, and smectite clay signatures mapped by MRO CRISM in mid-to-high northern latitudes.'
    },
    {
      author: 'Hassler, D. M., Zeitlin, C., Wimmer-Schweingruber, R. F., Ehresmann, B., Rafkin, S., Eigenbrode, J. L., et al.',
      year: '2014',
      title: "Mars' Surface Radiation Environment Measured with the Mars Science Laboratory's Curiosity Rover",
      journal: 'Science, 343(6169), 1244797',
      doi: '10.1126/science.1244797',
      note: 'Provides direct in-situ GCR and solar particle event (SPE) dose rate calibrations (~24–32 µSv/h) on the Martian surface.'
    },
    {
      author: 'Rodriguez-Manfredi, J. A., de la Torre Juárez, M., Alonso, A., Apéstigue, V., Arruego, I., Atienza, D., et al.',
      year: '2021',
      title: 'The Mars Environmental Dynamics Analyzer (MEDA) Instrument Suite on the Mars 2020 Mission',
      journal: 'Space Science Reviews, 217(3), 48',
      doi: '10.1007/s11214-021-00816-9',
      note: 'In-situ diurnal atmospheric pressure, 3D wind shear, thermal flux, and dust optical depth (RDS) operational sensor documentation.'
    },
    {
      author: 'Smith, D. E., Zuber, M. T., Frey, H. V., Garvin, J. B., Head, J. W., Muhleman, D. O., et al.',
      year: '2001',
      title: 'Mars Orbiter Laser Altimeter: Experiment summary and selected results with the MGS mapping mission',
      journal: 'Journal of Geophysical Research: Planets, 106(E10), 23689-23722',
      doi: '10.1029/2000JE001464',
      note: 'Primary reference for Mars Global Surveyor MOLA global topography, elevation reference datum (0-datum geoid), and regional slope statistics.'
    },
    {
      author: 'McEwen, A. S., Eliason, E. M., Sullivan, R. J., et al.',
      year: '2007',
      title: 'Mars Reconnaissance Orbiter\'s High Resolution Imaging Science Experiment (HiRISE)',
      journal: 'Journal of Geophysical Research: Planets, 112(E5)',
      doi: '10.1029/2005JE002605',
      note: 'Instrument calibration and 25-30 cm/pixel imaging methodology used for decametric boulder mapping and periglacial contraction polygon classification.'
    },
    {
      author: 'NASA Planetary Data System (PDS) Geosciences Node',
      year: '2026',
      title: 'Planetary Data System Data Release 78 (MRO, Mars 2020, MSL)',
      journal: 'Washington University in St. Louis / NASA PDS',
      doi: 'https://pds.nasa.gov',
      note: 'Primary public data delivery service providing calibrated RDR products for MOLA, HiRISE, SHARAD, CRISM, and MEDA.'
    }
  ];

  return (
    <div className="flex-1 overflow-y-auto bg-[#0b0d12] text-[#d6d9e0] select-text">
      {/* Top Breadcrumb */}
      <div className="hairline-b bg-[#0e1117] px-6 py-2.5 text-xs font-mono text-[#8b95a5]">
        <span>MARSWEAVE</span> <span className="text-gray-600">/</span> <span className="text-white">SCIENTIFIC SOURCES & CITATIONS</span>
      </div>

      <div className="max-w-5xl mx-auto px-6 py-12 md:py-16 space-y-10">
        {/* Title Header */}
        <div className="space-y-4 max-w-3xl">
          <div className="inline-block text-[11px] font-mono text-[#c85a32] uppercase tracking-wider">
            PEER-REVIEWED SCIENTIFIC FOUNDATION
          </div>
          <h1 className="text-3xl md:text-5xl font-sans font-bold tracking-tight text-white leading-tight">
            Scientific Sources & References
          </h1>
          <p className="text-sm md:text-base text-[#9ba5b5] font-sans leading-relaxed">
            The spatial models, dielectric assumptions, spectral absorption bands, and environmental constants implemented in MARSWEAVE are derived from published peer-reviewed planetary literature.
          </p>
        </div>

        {/* Citations List */}
        <div className="space-y-4">
          {citations.map((cite, idx) => (
            <div
              key={idx}
              className="bg-[#10141d] border border-[#1c2230] p-5 space-y-2 font-sans text-xs hover:border-gray-700 transition"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="text-white font-semibold text-sm leading-snug">
                  {cite.title}
                </div>
                <span className="font-mono text-xs text-[#c85a32] font-bold shrink-0">
                  {cite.year}
                </span>
              </div>

              <div className="text-[#8b95a5] text-xs font-sans">
                {cite.author}
              </div>

              <div className="text-xs text-[#3898b8] font-mono">
                {cite.journal}
              </div>

              <p className="text-[#9ba5b5] text-xs leading-relaxed pt-1.5 hairline-t">
                {cite.note}
              </p>

              <div className="text-[11px] font-mono text-[#6b7788]">
                DOI / REF: {cite.doi}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
