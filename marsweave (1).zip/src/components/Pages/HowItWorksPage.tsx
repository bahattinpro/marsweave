/**
 * MARSWEAVE — How It Works / Scientific Pipeline View
 * An interactive, 9-stage engineering pipeline illustrating the transformation
 * of raw NASA orbital data into an adaptive EVA mission plan.
 */

import React, { useState } from 'react';
import {
  Database,
  Layers,
  Wind,
  Target,
  AlertTriangle,
  Route,
  Activity,
  RefreshCw,
  FileText,
  ChevronDown,
  ChevronUp,
  ArrowRight,
  Info
} from 'lucide-react';

interface HowItWorksPageProps {
  onLaunchSimulator: () => void;
}

interface PipelineStage {
  id: string;
  step: string;
  title: string;
  subtitle: string;
  icon: React.ReactNode;
  dataUsed: string;
  derivedOutputs: string;
  modelledFactors: string;
  uncertainty: string;
  missionImpact: string;
}

export const HowItWorksPage: React.FC<HowItWorksPageProps> = ({ onLaunchSimulator }) => {
  const [activeStageId, setActiveStageId] = useState<string>('stage-01');

  const pipelineStages: PipelineStage[] = [
    {
      id: 'stage-01',
      step: '01',
      title: 'NASA OBSERVATIONS',
      subtitle: 'Ingestion of multi-mission raw telemetry and archival products',
      icon: <Database className="w-4 h-4 text-[#3898b8]" />,
      dataUsed: 'MGS MOLA laser altimetry, MRO HiRISE 25cm/px imagery, MRO SHARAD radar echograms, MRO CRISM hyperspectral cubes (544 bands), 2001 Mars Odyssey THEMIS thermal IR, Mars 2020 MEDA atmospheric measurements, MSL RAD surface radiation records.',
      derivedOutputs: 'Georeferenced raw raster datasets referenced to the Mars MOLA 0-datum geoid at Arcadia Planitia (39.3°N, 171.4°W).',
      modelledFactors: 'Atmospheric optical depth correction (volcano scan technique) for CRISM; orbital ephemeris propagation for relay links.',
      uncertainty: 'HiRISE coverage is targeted in discrete swathes; intermediate sectors use CTX context interpolation (6m/px).',
      missionImpact: 'Establishes the empirical baseline upon which all subsequent navigation and scientific conclusions rest.'
    },
    {
      id: 'stage-02',
      step: '02',
      title: 'DATA FUSION',
      subtitle: 'Multi-resolution spatial harmonization and discrete grid projection',
      icon: <Layers className="w-4 h-4 text-[#3898b8]" />,
      dataUsed: 'Fused MOLA DEM (463m), CTX context (6m), and HiRISE digital terrain models (1m).',
      derivedOutputs: 'Continuous 50 × 50 discrete surface matrix where each cell represents an area of ~136 × 136 meters.',
      modelledFactors: 'Bicubic elevation resampling with micro-roughness noise injection calibrated from HiRISE stereophotogrammetry.',
      uncertainty: 'Elevation interpolation uncertainty is ±1.2m on smooth plains, rising to ±4.8m near crater rims.',
      missionImpact: 'Ensures spatial alignment so that a mineral spectral signature matches the exact physical terrain coordinate.'
    },
    {
      id: 'stage-03',
      step: '03',
      title: 'MARS ENVIRONMENT MODEL',
      subtitle: 'Dynamic boundary layer atmosphere, solar insolation, and radiation flux',
      icon: <Wind className="w-4 h-4 text-[#c85a32]" />,
      dataUsed: 'Perseverance MEDA surface sensor records, MRO MCS vertical limb soundings, MSL Curiosity RAD energetic particle counts.',
      derivedOutputs: 'Diurnal surface temperature swings (-85°C to -42°C), ambient pressure (~680 Pa), 3D wind vectors, cosmic ray dose (~28 µSv/h).',
      modelledFactors: 'Extrapolation of Jezero Crater boundary-layer meteorological models to Arcadia Planitia mid-latitudes.',
      uncertainty: 'Regional dust fronts can surge optical depth from τ = 0.5 to τ = 1.8 within hours during southern spring.',
      missionImpact: 'Governs suit heater energy consumption, astronaut metabolic work rate, and battery endurance limits.'
    },
    {
      id: 'stage-04',
      step: '04',
      title: 'SCIENCE TARGET IDENTIFICATION',
      subtitle: 'Hyperspectral signature matching and dielectric ice reflection modeling',
      icon: <Target className="w-4 h-4 text-[#3898b8]" />,
      dataUsed: 'CRISM targeted mode radiance products, SHARAD radargrams, THEMIS thermal inertia maps.',
      derivedOutputs: 'Prioritized candidate science targets with specific observation protocols (e.g. core drill, multispectral sweep, contact probe).',
      modelledFactors: 'Dielectric constant estimation (ε = 3.12) indicating shallow pure water ice; 1.4µm/1.9µm absorption depth analysis.',
      uncertainty: 'Shallow dust mantles can attenuate weak phyllosilicate absorption bands; thermal inertia resolves unmantled bedrock.',
      missionImpact: 'Converts abstract coordinate waypoints into high-value scientific exploration stations.'
    },
    {
      id: 'stage-05',
      step: '05',
      title: 'TERRAIN HAZARD ESTIMATION',
      subtitle: 'Multi-criteria spatial risk index formulation',
      icon: <AlertTriangle className="w-4 h-4 text-[#c85a32]" />,
      dataUsed: 'Local elevation gradients, HiRISE boulder distributions, crater rim geomorphology.',
      derivedOutputs: 'Normalized hazard score (0.0 to 1.0) and discrete categorization (SAFE, CAUTION, HIGH RISK, CRITICAL).',
      modelledFactors: 'Tobler hiking velocity adjustment for 0.38g gravity; slope thresholding (14° caution, 25° hard locomotion cutoff).',
      uncertainty: 'Sub-pixel boulders (< 25 cm) can cause localized footing shifts not fully resolvable from orbit.',
      missionImpact: 'Prevents routing astronauts into scree slopes or boulder fields exceeding pressurized suit mechanical limits.'
    },
    {
      id: 'stage-06',
      step: '06',
      title: 'MULTI-OBJECTIVE A* ROUTE OPTIMIZATION',
      subtitle: 'Pareto-optimal pathfinding balancing distance, safety, comms, and science',
      icon: <Route className="w-4 h-4 text-[#3898b8]" />,
      dataUsed: 'Hazard grid, science reward layer, orbital communication relay mask, mission profile constraints.',
      derivedOutputs: 'Three candidate routes (Route Alpha: Balanced, Route Beta: Science Yield, Route Gamma: Direct Shortest).',
      modelledFactors: 'Dynamic weight vector driven by user mission objective (Water, Geology, Mineralogy, Terrain Survey, Multi-Science).',
      uncertainty: 'Multi-objective heuristic approximations are evaluated across 3,500 graph search iterations.',
      missionImpact: 'Produces an explainable plan showing exactly why specific hazardous corridors were avoided.'
    },
    {
      id: 'stage-07',
      step: '07',
      title: 'EVA SIMULATION ENGINE',
      subtitle: 'Discrete timeline execution tracking life-support vitals and orbital passes',
      icon: <Activity className="w-4 h-4 text-[#3898b8]" />,
      dataUsed: 'Route waypoints, Tobler traversal speeds, astronaut metabolic wattage parameters.',
      derivedOutputs: 'Minute-by-minute suit battery %, primary O2 %, distance covered, heart rate, and sun elevation angle.',
      modelledFactors: 'Linear position interpolation with slope-dependent metabolic energy consumption.',
      uncertainty: 'Individual astronaut physical fitness and metabolic efficiency can vary baseline consumption by ±12%.',
      missionImpact: 'Enables flight controllers to anticipate consumables depletion well before reaching critical thresholds.'
    },
    {
      id: 'stage-08',
      step: '08',
      title: 'DYNAMIC CONTINGENCY REPLANNING',
      subtitle: 'Real-time environmental adaptation and differential metric logging',
      icon: <RefreshCw className="w-4 h-4 text-[#c85a32]" />,
      dataUsed: 'Simulated atmospheric dust optical depth surges, satellite relay loss-of-signal events.',
      derivedOutputs: 'Recalculated detour route with explicit comparative deltas (ΔTime, ΔRisk, ΔScience, ΔComms).',
      modelledFactors: 'Emergency cost-weight rebalancing favoring firm low-gradient bedrock corridors.',
      uncertainty: 'Environmental front progression rate depends on regional atmospheric dust storm dynamics.',
      missionImpact: 'Empowers crew and mission control to adaptively respond to dynamic Martian weather changes.'
    },
    {
      id: 'stage-09',
      step: '09',
      title: 'POST-MISSION DEBRIEF REPORT',
      subtitle: 'Archival provenance tracking, sample cataloging, and debrief documentation',
      icon: <FileText className="w-4 h-4 text-[#3898b8]" />,
      dataUsed: 'Final traversed GPS odometry, collected sample IDs, cumulative radiation dose, environmental timeline.',
      derivedOutputs: 'Printable operational debrief report with full NASA PDS Release 78 citations and evidence chains.',
      modelledFactors: 'Cumulative dosimetric integration and mission safety margin verification.',
      uncertainty: 'Complete operational accountability backed by verifiable NASA archival identifiers.',
      missionImpact: 'Ensures scientific reproducibility and rigorous mission documentation for NASA science directorates.'
    }
  ];

  const activeStage = pipelineStages.find(s => s.id === activeStageId) || pipelineStages[0];

  return (
    <div className="flex-1 overflow-y-auto bg-[#0b0d12] text-[#d6d9e0] select-text">
      {/* Top Breadcrumb */}
      <div className="hairline-b bg-[#0e1117] px-6 py-2.5 text-xs font-mono text-[#8b95a5]">
        <span>MARSWEAVE</span> <span className="text-gray-600">/</span> <span className="text-white">SYSTEM PIPELINE</span>
      </div>

      <div className="max-w-5xl mx-auto px-6 py-12 md:py-16 space-y-12">
        {/* Title Header */}
        <div className="space-y-4 max-w-3xl">
          <div className="inline-block text-[11px] font-mono text-[#c85a32] uppercase tracking-wider">
            SCIENTIFIC INFORMATION ARCHITECTURE
          </div>
          <h1 className="text-3xl md:text-5xl font-sans font-bold tracking-tight text-white leading-tight">
            The 9-Stage MARSWEAVE Scientific Pipeline
          </h1>
          <p className="text-sm md:text-base text-[#9ba5b5] font-sans leading-relaxed">
            From raw NASA Planetary Data System orbital products to an adaptive on-surface traversal plan, explore each computational stage of our decision-support engine.
          </p>
        </div>

        {/* Interactive Vertical Pipeline Layout */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
          {/* Left Column: Vertical Pipeline Step Selector */}
          <div className="md:col-span-5 space-y-2 font-mono text-xs">
            {pipelineStages.map((stage, idx) => {
              const isActive = stage.id === activeStageId;
              return (
                <div key={stage.id} className="relative">
                  {/* Connecting Line */}
                  {idx < pipelineStages.length - 1 && (
                    <div className="absolute left-5 top-9 bottom-0 w-px bg-[#1c2230] z-0" />
                  )}

                  <button
                    onClick={() => setActiveStageId(stage.id)}
                    className={`w-full p-3 text-left transition flex items-center gap-3 relative z-10 border ${
                      isActive
                        ? 'bg-[#141a26] border-[#3898b8] text-white shadow-sm'
                        : 'bg-[#0f131c] border-[#1c2230] text-[#8b95a5] hover:border-gray-700 hover:text-[#cdd3de]'
                    }`}
                  >
                    <div className={`w-5 h-5 rounded-full flex items-center justify-center font-mono text-[10px] font-bold shrink-0 ${
                      isActive ? 'bg-[#3898b8] text-black' : 'bg-[#181e2b] text-[#8b95a5]'
                    }`}>
                      {stage.step}
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="font-semibold truncate">{stage.title}</div>
                      <div className="text-[10px] text-[#6b7788] truncate font-sans">{stage.subtitle}</div>
                    </div>

                    {isActive && <div className="w-1.5 h-1.5 rounded-full bg-[#3898b8] shrink-0" />}
                  </button>
                </div>
              );
            })}
          </div>

          {/* Right Column: Deep Stage Inspection Panel */}
          <div className="md:col-span-7 bg-[#10141d] border border-[#1c2230] p-6 space-y-6">
            <div className="hairline-b pb-4">
              <div className="flex items-center gap-2 text-xs font-mono text-[#3898b8] mb-1">
                <span>STAGE {activeStage.step} OF 09</span>
                <span className="text-[#647082]">•</span>
                <span>INSPECTION</span>
              </div>
              <h2 className="text-xl font-bold text-white font-sans tracking-tight">
                {activeStage.title}
              </h2>
              <p className="text-xs text-[#8b95a5] font-sans mt-1">
                {activeStage.subtitle}
              </p>
            </div>

            {/* Stage Specifications */}
            <div className="space-y-4 text-xs font-sans">
              <div>
                <span className="font-mono text-[10px] text-[#6b7788] uppercase tracking-wider block mb-1">
                  1. INPUT NASA DATASETS & INSTRUMENTS
                </span>
                <p className="text-[#cdd3de] bg-[#0b0e14] p-3 border border-[#1c2230] font-mono leading-relaxed">
                  {activeStage.dataUsed}
                </p>
              </div>

              <div>
                <span className="font-mono text-[10px] text-[#6b7788] uppercase tracking-wider block mb-1">
                  2. DERIVED SCIENTIFIC PROPERTIES
                </span>
                <p className="text-[#cdd3de] bg-[#0b0e14] p-3 border border-[#1c2230] leading-relaxed">
                  {activeStage.derivedOutputs}
                </p>
              </div>

              <div>
                <span className="font-mono text-[10px] text-[#6b7788] uppercase tracking-wider block mb-1">
                  3. MODELLED FACTORS & CALIBRATION
                </span>
                <p className="text-[#cdd3de] bg-[#0b0e14] p-3 border border-[#1c2230] leading-relaxed">
                  {activeStage.modelledFactors}
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
                <div className="bg-[#0b0e14] p-3 border border-[#1c2230]">
                  <span className="font-mono text-[10px] text-[#c85a32] uppercase tracking-wider block mb-1 font-semibold">
                    SCIENTIFIC UNCERTAINTY
                  </span>
                  <p className="text-[#8b95a5] leading-relaxed">
                    {activeStage.uncertainty}
                  </p>
                </div>
                <div className="bg-[#0b0e14] p-3 border border-[#1c2230]">
                  <span className="font-mono text-[10px] text-[#3898b8] uppercase tracking-wider block mb-1 font-semibold">
                    EVA OPERATIONAL IMPACT
                  </span>
                  <p className="text-[#8b95a5] leading-relaxed">
                    {activeStage.missionImpact}
                  </p>
                </div>
              </div>
            </div>

            <div className="hairline-t pt-4 flex items-center justify-between">
              <span className="text-[11px] font-mono text-[#8b95a5]">Grounded in NASA PDS archival standards</span>
              <button
                onClick={onLaunchSimulator}
                className="text-xs font-mono text-[#c85a32] hover:text-[#e06a3e] flex items-center gap-1.5 transition cursor-pointer"
              >
                <span>TEST IN SIMULATOR</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
