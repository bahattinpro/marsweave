/**
 * MARSWEAVE — NASA Planetary Data Catalog View
 * A formal scientific instrument and data product catalog with verifiable PDS citations.
 */

import React, { useState } from 'react';
import { NASA_PROVENANCE_REGISTRY } from '../../data/arcadiaData';
import {
  Database,
  Search,
  Filter,
  ExternalLink,
  ShieldCheck,
  Info,
  CheckCircle2
} from 'lucide-react';

export const NasaDataPage: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>('ALL');

  const statuses = ['ALL', 'REAL NASA ARCHIVE', 'DERIVED', 'MODELLED', 'SIMULATED'];

  const filteredEntries = NASA_PROVENANCE_REGISTRY.filter(entry => {
    const matchesSearch =
      entry.instrument.toLowerCase().includes(searchQuery.toLowerCase()) ||
      entry.instrumentFull.toLowerCase().includes(searchQuery.toLowerCase()) ||
      entry.mission.toLowerCase().includes(searchQuery.toLowerCase()) ||
      entry.usedInMarsweaveFor.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus =
      selectedStatusFilter === 'ALL' || entry.dataStatus === selectedStatusFilter;

    return matchesSearch && matchesStatus;
  });

  return (
    <div className="flex-1 overflow-y-auto bg-[#0b0d12] text-[#d6d9e0] select-text">
      {/* Top Breadcrumb */}
      <div className="hairline-b bg-[#0e1117] px-6 py-2.5 text-xs font-mono text-[#8b95a5]">
        <span>MARSWEAVE</span> <span className="text-gray-600">/</span> <span className="text-white">NASA DATA CATALOG</span>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-12 md:py-16 space-y-10">
        {/* Title Header */}
        <div className="space-y-4 max-w-3xl">
          <div className="inline-block text-[11px] font-mono text-[#c85a32] uppercase tracking-wider">
            PLANETARY DATA SYSTEM REPOSITORY
          </div>
          <h1 className="text-3xl md:text-5xl font-sans font-bold tracking-tight text-white leading-tight">
            NASA Mission Data Provenance
          </h1>
          <p className="text-sm md:text-base text-[#9ba5b5] font-sans leading-relaxed">
            Every layer, calculation, and waypoint in MARSWEAVE is cross-referenced against published NASA planetary mission archives. We explicitly distinguish direct archival measurements from derived models and simulated operational scenarios.
          </p>
        </div>

        {/* Filter & Search Bar */}
        <div className="bg-[#10141d] border border-[#1c2230] p-4 flex flex-wrap items-center justify-between gap-4 font-mono text-xs">
          <div className="flex items-center gap-2 flex-1 min-w-[240px]">
            <Search className="w-4 h-4 text-[#8b95a5]" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search by instrument, mission, or measurement type..."
              className="w-full bg-transparent outline-none text-white placeholder-[#6b7788]"
            />
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[#6b7788] uppercase text-[10px]">FILTER STATUS:</span>
            <div className="flex flex-wrap gap-1">
              {statuses.map(status => (
                <button
                  key={status}
                  onClick={() => setSelectedStatusFilter(status)}
                  className={`px-2.5 py-1 rounded text-[10.5px] transition ${
                    selectedStatusFilter === status
                      ? 'bg-[#3898b8] text-black font-semibold'
                      : 'bg-[#181d26] text-[#8b95a5] hover:text-white'
                  }`}
                >
                  {status}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Scientific Data Table */}
        <div className="space-y-4">
          <div className="text-xs font-mono text-[#8b95a5] flex items-center justify-between">
            <span>SHOWING {filteredEntries.length} OF {NASA_PROVENANCE_REGISTRY.length} DATASETS</span>
            <span>NASA PDS RELEASE 78 COMPLIANT</span>
          </div>

          <div className="space-y-3 font-sans">
            {filteredEntries.map(entry => (
              <div
                key={entry.instrument}
                className="bg-[#10141d] border border-[#1c2230] p-5 space-y-3 hover:border-gray-700 transition"
              >
                {/* Header row */}
                <div className="flex flex-wrap items-start justify-between gap-3 hairline-b pb-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <h2 className="text-base font-bold text-white font-sans">
                        {entry.instrument}
                      </h2>
                      <span className="text-xs text-[#8b95a5]">
                        ({entry.instrumentFull})
                      </span>
                    </div>
                    <div className="text-xs font-mono text-[#3898b8] mt-0.5">
                      {entry.mission} • {entry.agency}
                    </div>
                  </div>

                  <span
                    className={`text-[9.5px] font-mono px-2 py-0.5 rounded font-semibold uppercase ${
                      entry.dataStatus === 'REAL NASA ARCHIVE'
                        ? 'bg-[#18261e] text-[#48b577] border border-[#234230]'
                        : entry.dataStatus === 'DERIVED'
                        ? 'bg-[#142330] text-[#3898b8] border border-[#1e3448]'
                        : entry.dataStatus === 'MODELLED'
                        ? 'bg-[#2a2214] text-[#d49938] border border-[#44351d]'
                        : 'bg-[#25192d] text-[#b37cd6] border border-[#3f274e]'
                    }`}
                  >
                    {entry.dataStatus}
                  </span>
                </div>

                {/* Technical Specifications Strip */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 font-mono text-xs bg-[#0b0e14] p-3 border border-[#1c2230]">
                  <div>
                    <span className="text-[10px] text-[#6b7788] block">PDS DATASET ID</span>
                    <span className="text-white truncate block">{entry.pdsDatasetId}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-[#6b7788] block">SPATIAL RESOLUTION</span>
                    <span className="text-white">{entry.spatialResolution}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-[#6b7788] block">BANDWIDTH / CHANNELS</span>
                    <span className="text-white truncate block">{entry.spectralRange}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-[#6b7788] block">COVERAGE CONFIDENCE</span>
                    <span className={entry.confidence === 'HIGH' ? 'text-[#48b577] font-semibold' : 'text-[#d49938] font-semibold'}>
                      {entry.confidence} CONFIDENCE
                    </span>
                  </div>
                </div>

                {/* Role and Methodology */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div>
                    <span className="font-mono text-[10px] text-[#8b95a5] uppercase tracking-wider block mb-1">
                      WHAT IT CONTRIBUTES TO MARSWEAVE:
                    </span>
                    <p className="text-[#cdd3de] leading-relaxed">
                      {entry.usedInMarsweaveFor}
                    </p>
                  </div>
                  <div>
                    <span className="font-mono text-[10px] text-[#c85a32] uppercase tracking-wider block mb-1">
                      METHODOLOGICAL CAVEAT & HONESTY:
                    </span>
                    <p className="text-[#8b95a5] font-mono leading-relaxed text-[11px]">
                      {entry.scientificHonestyNotes}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
