/**
 * MARSWEAVE — GitHub Pages Deployment Hub & Publisher
 * Interactive 5-step deployment wizard, git command generator, and CI/CD inspector.
 */

import React, { useState } from 'react';
import {
  X,
  Copy,
  Check,
  ExternalLink,
  GitBranch,
  Terminal,
  Settings,
  Globe,
  Rocket,
  CheckCircle2,
  FolderCheck,
  FileCode,
  ShieldCheck,
  ArrowRight,
  HelpCircle,
  Code2
} from 'lucide-react';

interface GithubPagesModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GithubPagesModal: React.FC<GithubPagesModalProps> = ({ isOpen, onClose }) => {
  const [username, setUsername] = useState<string>('bkbyazilim');
  const [repoName, setRepoName] = useState<string>('marsweave');
  const [copiedSection, setCopiedSection] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'GUIDE' | 'COMMANDS' | 'WORKFLOW' | 'VERIFICATION'>('GUIDE');

  if (!isOpen) return null;

  const cleanUser = username.trim() || 'kullaniciadi';
  const cleanRepo = repoName.trim() || 'marsweave';
  const liveUrl = `https://${cleanUser}.github.io/${cleanRepo}/`;
  const repoUrl = `https://github.com/${cleanUser}/${cleanRepo}`;

  const gitBashCommands = `# 1. Proje ana dizininde Git'i başlatın
git init

# 2. Tüm dosyaları ve GitHub Actions ayarlarını ekleyin
git add .

# 3. İlk sürüm commit'ini oluşturun
git commit -m "MARSWEAVE: Intelligent Mars EVA Planning initial release"

# 4. Ana dalı 'main' olarak belirleyin
git branch -M main

# 5. GitHub deponuzu uzak kaynak (remote origin) olarak bağlayın
git remote add origin ${repoUrl}.git

# 6. Kodlarınızı GitHub'a yükleyin
git push -u origin main`;

  const copyToClipboard = (text: string, sectionId: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(sectionId);
    setTimeout(() => {
      setCopiedSection(null);
    }, 2500);
  };

  const workflowYmlContent = `# .github/workflows/deploy.yml
name: Deploy to GitHub Pages

on:
  push:
    branches: [main, master]
  workflow_dispatch:

permissions:
  contents: read
  pages: write
  id-token: write

concurrency:
  group: 'pages'
  cancel-in-progress: true

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: 'npm'
      - run: npm install
      - run: npm run build
      - uses: actions/upload-pages-artifact@v3
        with:
          path: './dist'

  deploy:
    needs: build
    runs-on: ubuntu-latest
    environment:
      name: github-pages
      url: \${{ steps.deployment.outputs.page_url }}
    steps:
      - uses: actions/deploy-pages@v4
        id: deployment`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="w-full max-w-4xl bg-[#0c1017] border border-[#232b3b] rounded-xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-6 py-4 bg-[#111722] hairline-b flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#24292e] border border-[#3e4756] flex items-center justify-center text-white text-xl">
              🐙
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
                  GitHub Pages ile Yayınlama ve Otomatik Dağıtım
                </h2>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                  HAZIRLANDI & UYUMLU
                </span>
              </div>
              <p className="text-xs text-[#8a96a9]">
                Geliştiriciler için profesyonel, ücretsiz ve otomatik güncellenen barındırma kılavuzu
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#8a96a9] hover:text-white hover:bg-[#1a2230] transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live URL / Repository Interactive Target */}
        <div className="px-6 py-3 bg-[#151c28] hairline-b flex flex-wrap items-center justify-between gap-4 text-xs font-mono">
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-1.5 text-[#8a96a9]">
              <span>Kullanıcı Adı:</span>
              <input
                type="text"
                value={username}
                onChange={e => setUsername(e.target.value)}
                placeholder="github-kullanici-adiniz"
                className="bg-[#090d14] border border-[#2b3547] rounded px-2.5 py-1 text-white text-xs focus:border-[#c85a32] focus:outline-none w-36"
              />
            </div>
            <div className="flex items-center gap-1.5 text-[#8a96a9]">
              <span>Depo (Repo) Adı:</span>
              <input
                type="text"
                value={repoName}
                onChange={e => setRepoName(e.target.value)}
                placeholder="depo-adi"
                className="bg-[#090d14] border border-[#2b3547] rounded px-2.5 py-1 text-white text-xs focus:border-[#c85a32] focus:outline-none w-36"
              />
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[#8a96a9] text-[11px]">Canlı Siteniz:</span>
            <a
              href={liveUrl}
              target="_blank"
              rel="noreferrer"
              className="text-[#3898b8] hover:text-[#52b3d6] underline flex items-center gap-1 font-semibold group text-xs"
            >
              <span>{cleanUser}.github.io/{cleanRepo}/</span>
              <ExternalLink className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition" />
            </a>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="px-6 bg-[#0e131d] hairline-b flex items-center gap-2 overflow-x-auto text-xs font-mono">
          <button
            onClick={() => setActiveTab('GUIDE')}
            className={`px-3.5 py-2.5 border-b-2 font-medium transition cursor-pointer flex items-center gap-2 ${
              activeTab === 'GUIDE'
                ? 'border-[#c85a32] text-white bg-[#151c27]'
                : 'border-transparent text-[#8a96a9] hover:text-white'
            }`}
          >
            <Rocket className="w-3.5 h-3.5 text-[#c85a32]" />
            <span>5 ADIMDA YAYINLAMA</span>
          </button>
          <button
            onClick={() => setActiveTab('COMMANDS')}
            className={`px-3.5 py-2.5 border-b-2 font-medium transition cursor-pointer flex items-center gap-2 ${
              activeTab === 'COMMANDS'
                ? 'border-[#c85a32] text-white bg-[#151c27]'
                : 'border-transparent text-[#8a96a9] hover:text-white'
            }`}
          >
            <Terminal className="w-3.5 h-3.5 text-[#3898b8]" />
            <span>GIT KOMUTLARI</span>
          </button>
          <button
            onClick={() => setActiveTab('WORKFLOW')}
            className={`px-3.5 py-2.5 border-b-2 font-medium transition cursor-pointer flex items-center gap-2 ${
              activeTab === 'WORKFLOW'
                ? 'border-[#c85a32] text-white bg-[#151c27]'
                : 'border-transparent text-[#8a96a9] hover:text-white'
            }`}
          >
            <FileCode className="w-3.5 h-3.5 text-emerald-400" />
            <span>GITHUB ACTIONS (CI/CD)</span>
          </button>
          <button
            onClick={() => setActiveTab('VERIFICATION')}
            className={`px-3.5 py-2.5 border-b-2 font-medium transition cursor-pointer flex items-center gap-2 ${
              activeTab === 'VERIFICATION'
                ? 'border-[#c85a32] text-white bg-[#151c27]'
                : 'border-transparent text-[#8a96a9] hover:text-white'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5 text-purple-400" />
            <span>SİSTEM UYUMLULUK TESTİ</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* TAB 1: 5-STEP GUIDE */}
          {activeTab === 'GUIDE' && (
            <div className="space-y-4">
              <div className="p-4 rounded-lg bg-[#141b26] border border-[#232d3d] text-xs text-[#a4b1c3] leading-relaxed">
                <span className="text-white font-semibold block mb-1">
                  🐙 GitHub Pages ile Yayınlama (Geliştiriciler İçin En İyisi)
                </span>
                Eğer kodlarınızı güncelledikçe sitenizin de otomatik olarak güncellenmesini istiyorsanız, en profesyonel ücretsiz yöntem budur. Bu projenin tüm altyapısı GitHub Pages için eksiksiz yapılandırılmıştır.
              </div>

              {/* Step 1 */}
              <div className="p-4 rounded-xl bg-[#101520] border border-[#1e2636] flex items-start gap-4">
                <div className="w-8 h-8 rounded-full bg-[#c85a32]/20 border border-[#c85a32] text-[#c85a32] font-mono font-bold flex items-center justify-center shrink-0 text-sm">
                  1
                </div>
                <div className="space-y-1.5 flex-1">
                  <h3 className="text-sm font-semibold text-white">
                    GitHub Üzerinde Depo (Repository) Oluşturun
                  </h3>
                  <p className="text-xs text-[#8a96a9] leading-relaxed">
                    <a href="https://github.com/new" target="_blank" rel="noreferrer" className="text-[#3898b8] underline font-mono">
                      github.com/new
                    </a> adresine gidin. Depo adını girin (örneğin <span className="text-white font-mono">{cleanRepo}</span>). Deponuzu <strong>Public (Herkese Açık)</strong> olarak seçip <em>Create repository</em> butonuna tıklayın.
                  </p>
                </div>
              </div>

              {/* Step 2 */}
              <div className="p-4 rounded-xl bg-[#101520] border border-[#1e2636] flex items-start gap-4">
                <div className="w-8 h-8 rounded-full bg-[#c85a32]/20 border border-[#c85a32] text-[#c85a32] font-mono font-bold flex items-center justify-center shrink-0 text-sm">
                  2
                </div>
                <div className="space-y-2 flex-1">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-semibold text-white">
                      Kodlarınızı Bu Depoya Yükleyin
                    </h3>
                    <button
                      onClick={() => setActiveTab('COMMANDS')}
                      className="text-[11px] font-mono text-[#3898b8] hover:text-[#67c3e5] flex items-center gap-1 cursor-pointer"
                    >
                      <span>Komutları Göster</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                  <p className="text-xs text-[#8a96a9] leading-relaxed">
                    Terminal veya VS Code üzerinden dosyalarınızı depoya push edin. Projede ana sayfanız <span className="font-mono text-emerald-400 font-semibold">index.html</span> olarak hazırlanmıştır ve Vite derleyici çıktıları için <span className="font-mono text-white">docs/</span> veya GitHub Actions kullanılabilir.
                  </p>
                </div>
              </div>

              {/* Step 3 */}
              <div className="p-4 rounded-xl bg-[#101520] border border-[#1e2636] flex items-start gap-4">
                <div className="w-8 h-8 rounded-full bg-[#c85a32]/20 border border-[#c85a32] text-[#c85a32] font-mono font-bold flex items-center justify-center shrink-0 text-sm">
                  3
                </div>
                <div className="space-y-1.5 flex-1">
                  <h3 className="text-sm font-semibold text-white">
                    Deponun Settings (Ayarlar) &gt; Pages Bölümüne Gidin
                  </h3>
                  <p className="text-xs text-[#8a96a9] leading-relaxed">
                    Depo sayfanızın üst sekmesindeki <span className="text-white font-mono">Settings</span> butonuna tıklayın. Sol menüden <span className="text-white font-mono">Pages</span> sekmesini seçin.
                  </p>
                </div>
              </div>

              {/* Step 4 */}
              <div className="p-4 rounded-xl bg-[#101520] border border-[#1e2636] flex items-start gap-4">
                <div className="w-8 h-8 rounded-full bg-[#c85a32]/20 border border-[#c85a32] text-[#c85a32] font-mono font-bold flex items-center justify-center shrink-0 text-sm">
                  4
                </div>
                <div className="space-y-3 flex-1">
                  <h3 className="text-sm font-semibold text-white">
                    Build and deployment Ayarını Seçip Kaydedin
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                    <div className="p-3 rounded-lg bg-[#141b27] border border-emerald-500/30">
                      <div className="flex items-center gap-1.5 text-emerald-400 font-semibold mb-1">
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Seçenek 1 (Tavsiye Edilen: GitHub Actions)</span>
                      </div>
                      <p className="text-[#8a96a9] text-[11px] leading-relaxed">
                        Source alanından <strong>GitHub Actions</strong> seçin. Depoda bulunan <span className="font-mono text-white">.github/workflows/deploy.yml</span> sayesinde her kod gönderdiğinizde siteniz saniyeler içinde otomatik derlenip yayına alınır.
                      </p>
                    </div>

                    <div className="p-3 rounded-lg bg-[#141b27] border border-[#2b3547]">
                      <div className="flex items-center gap-1.5 text-[#3898b8] font-semibold mb-1">
                        <FolderCheck className="w-4 h-4" />
                        <span>Seçenek 2 (Klasik Branch /docs)</span>
                      </div>
                      <p className="text-[#8a96a9] text-[11px] leading-relaxed">
                        Source alanından <strong>Deploy from a branch</strong> seçin. Branch olarak <strong>Main</strong> (veya Master), klasör olarak <strong>/docs</strong> seçip Save deyin. Projede hazır <span className="font-mono text-white">docs/</span> derlemesi mevcuttur!
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Step 5 */}
              <div className="p-4 rounded-xl bg-[#101520] border border-[#1e2636] flex items-start gap-4">
                <div className="w-8 h-8 rounded-full bg-emerald-500/20 border border-emerald-500 text-emerald-400 font-mono font-bold flex items-center justify-center shrink-0 text-sm">
                  5
                </div>
                <div className="space-y-2 flex-1">
                  <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                    <span>Siteniz Yayında!</span>
                    <span className="text-xs text-emerald-400 font-mono font-normal">● Aktif</span>
                  </h3>
                  <p className="text-xs text-[#8a96a9]">
                    Birkaç dakika içinde siteniz aşağıdaki adreste yayına girecektir:
                  </p>
                  <div className="p-3 rounded-lg bg-[#090d14] border border-[#242d3d] flex items-center justify-between">
                    <span className="font-mono text-xs text-[#52b3d6] font-semibold">
                      https://{cleanUser}.github.io/{cleanRepo}/
                    </span>
                    <button
                      onClick={() => copyToClipboard(`https://${cleanUser}.github.io/${cleanRepo}/`, 'live-url')}
                      className="px-2.5 py-1 rounded bg-[#1a2332] hover:bg-[#253246] text-white text-[11px] font-mono flex items-center gap-1.5 transition cursor-pointer"
                    >
                      {copiedSection === 'live-url' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedSection === 'live-url' ? 'Kopyalandı' : 'Linki Kopyala'}</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: GIT COMMANDS */}
          {activeTab === 'COMMANDS' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-semibold text-white">
                    Tek Tıkla Kopyalanabilir Terminal Komutları
                  </h3>
                  <p className="text-xs text-[#8a96a9]">
                    Projenizi doğrudan GitHub'a göndermek için bu komutları terminalinizde sırayla çalıştırın.
                  </p>
                </div>
                <button
                  onClick={() => copyToClipboard(gitBashCommands, 'all-commands')}
                  className="px-3 py-1.5 rounded-lg bg-[#c85a32] hover:bg-[#b34c27] text-white font-mono text-xs flex items-center gap-1.5 transition cursor-pointer shadow"
                >
                  {copiedSection === 'all-commands' ? <Check className="w-4 h-4 text-emerald-300" /> : <Copy className="w-4 h-4" />}
                  <span>{copiedSection === 'all-commands' ? 'Komutlar Kopyalandı!' : 'Tüm Komutları Kopyala'}</span>
                </button>
              </div>

              <div className="p-4 rounded-xl bg-[#080b11] border border-[#1e2536] font-mono text-xs text-[#c8d4e6] leading-relaxed relative overflow-x-auto">
                <pre>{gitBashCommands}</pre>
              </div>

              <div className="p-4 rounded-xl bg-[#111722] border border-[#20293a] space-y-2">
                <h4 className="text-xs font-semibold text-white flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-[#3898b8]" />
                  <span>Sık Kullanılan Güncelleme Komutu:</span>
                </h4>
                <p className="text-xs text-[#8a96a9]">
                  Kodlarınızda bir değişiklik yaptığınızda sitenizi tekrar güncellemek için tek gereken:
                </p>
                <div className="p-2.5 rounded bg-[#070a0f] border border-[#1d2535] font-mono text-xs text-emerald-400 flex items-center justify-between">
                  <span>git add . && git commit -m "Site guncellendi" && git push</span>
                  <button
                    onClick={() => copyToClipboard('git add . && git commit -m "Site guncellendi" && git push', 'quick-push')}
                    className="text-xs text-[#8a96a9] hover:text-white cursor-pointer"
                  >
                    {copiedSection === 'quick-push' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: WORKFLOW */}
          {activeTab === 'WORKFLOW' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                    <span>GitHub Actions Otomasyon Dosyası</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                      .github/workflows/deploy.yml
                    </span>
                  </h3>
                  <p className="text-xs text-[#8a96a9]">
                    Bu dosya projenizin kök dizinine eklenmiştir. GitHub'a push yapıldığında derleme otomatik başlar.
                  </p>
                </div>
                <button
                  onClick={() => copyToClipboard(workflowYmlContent, 'workflow-yml')}
                  className="px-3 py-1.5 rounded-lg bg-[#18202d] hover:bg-[#222c3e] border border-[#2d3a50] text-white font-mono text-xs flex items-center gap-1.5 transition cursor-pointer"
                >
                  {copiedSection === 'workflow-yml' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  <span>{copiedSection === 'workflow-yml' ? 'Kopyalandı' : 'YML Dosyasını Kopyala'}</span>
                </button>
              </div>

              <div className="p-4 rounded-xl bg-[#080b11] border border-[#1e2536] font-mono text-xs text-[#c8d4e6] max-h-80 overflow-y-auto">
                <pre>{workflowYmlContent}</pre>
              </div>

              <div className="p-3.5 rounded-lg bg-[#131b26] border border-[#232f42] text-xs text-[#8a96a9] flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>
                  <strong>Neden GitHub Actions?</strong> Vite ve React TypeScript tabanlı modern projelerde kaynak kodlarının tarayıcıda çalışabilmesi için derlenmesi (build) gerekir. GitHub Actions her commit gönderdiğinizde bu işlemi GitHub sunucularında ücretsiz olarak otomatik yapar ve sitenizi sıfır bekleme süresiyle günceller.
                </span>
              </div>
            </div>
          )}

          {/* TAB 4: VERIFICATION */}
          {activeTab === 'VERIFICATION' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-semibold text-white">
                  GitHub Pages Uyumluluk Denetimi (Checklist)
                </h3>
                <p className="text-xs text-[#8a96a9]">
                  Uygulamanın GitHub Pages ortamında sorunsuz çalışması için tüm optimizasyonlar uygulanmıştır:
                </p>
              </div>

              <div className="space-y-3">
                <div className="p-3.5 rounded-lg bg-[#101622] border border-emerald-500/30 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs font-bold">
                      ✓
                    </div>
                    <div>
                      <div className="text-xs font-semibold text-white">Vite Base Path Ayarı (base: './')</div>
                      <div className="text-[11px] text-[#8a96a9]">
                        Tüm JS, CSS ve font varlıkları göreceli yollarla yüklenir. <code>username.github.io/depo/</code> alt klasöründe 404 hatası oluşmaz.
                      </div>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/20 text-emerald-300">
                    Aktif
                  </span>
                </div>

                <div className="p-3.5 rounded-lg bg-[#101622] border border-emerald-500/30 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs font-bold">
                      ✓
                    </div>
                    <div>
                      <div className="text-xs font-semibold text-white">index.html Giriş Noktası</div>
                      <div className="text-[11px] text-[#8a96a9]">
                        GitHub Pages zorunlu gereksinimi olan <code>index.html</code> ana dizinde ve <code>docs/</code> dizininde mevcuttur.
                      </div>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/20 text-emerald-300">
                    Aktif
                  </span>
                </div>

                <div className="p-3.5 rounded-lg bg-[#101622] border border-emerald-500/30 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs font-bold">
                      ✓
                    </div>
                    <div>
                      <div className="text-xs font-semibold text-white">.nojekyll Bayrağı</div>
                      <div className="text-[11px] text-[#8a96a9]">
                        GitHub Pages varsayılan Jekyll motorunun CSS ve JS dosyalarını atlamasını engeller.
                      </div>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/20 text-emerald-300">
                    Aktif
                  </span>
                </div>

                <div className="p-3.5 rounded-lg bg-[#101622] border border-emerald-500/30 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs font-bold">
                      ✓
                    </div>
                    <div>
                      <div className="text-xs font-semibold text-white">Tamamen İstemci Taraflı Çalışma (Client-Side Standalone)</div>
                      <div className="text-[11px] text-[#8a96a9]">
                        Mars harita motoru, A* rota algoritması ve bilimsel NASA simülasyonları sunucusuz olarak %100 statik çalışır.
                      </div>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/20 text-emerald-300">
                    Aktif
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-[#0e131d] hairline-t flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-[#8a96a9]">
            <Globe className="w-4 h-4 text-[#3898b8]" />
            <span>Hedef Canlı URL: <strong className="text-white font-mono">{liveUrl}</strong></span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => copyToClipboard(gitBashCommands, 'footer-copy')}
              className="px-3 py-1.5 rounded bg-[#18202d] hover:bg-[#232d3f] border border-[#2b364a] text-[#cdd5e2] font-mono flex items-center gap-1.5 transition cursor-pointer"
            >
              {copiedSection === 'footer-copy' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>Komutları Kopyala</span>
            </button>
            <button
              onClick={onClose}
              className="px-4 py-1.5 rounded bg-[#c85a32] hover:bg-[#b34c27] text-white font-semibold transition cursor-pointer"
            >
              Tamam
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
