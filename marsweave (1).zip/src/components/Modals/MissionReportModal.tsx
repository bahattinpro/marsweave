/**
 * MARSWEAVE — Post-EVA Mission Debrief & Scientific Operational Report Modal
 */

import React from 'react';
import {
  RouteCandidate,
  MissionProfile,
  EnvironmentalConditions,
  AstronautTelemetry,
  ScienceTarget
} from '../../types/marsweave';
import {
  FileText,
  Award,
  CheckCircle2,
  Mountain,
  Clock,
  Sparkles,
  ShieldCheck,
  Radio,
  Printer,
  X,
  RotateCcw
} from 'lucide-react';

interface MissionReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedRoute: RouteCandidate;
  profile: MissionProfile;
  environment: EnvironmentalConditions;
  astronautTelemetry: AstronautTelemetry;
  scienceTargets: ScienceTarget[];
  onRestartMission: () => void;
}

export const MissionReportModal: React.FC<MissionReportModalProps> = ({
  isOpen,
  onClose,
  selectedRoute,
  profile,
  environment,
  astronautTelemetry,
  scienceTargets,
  onRestartMission
}) => {
  if (!isOpen) return null;

  const visitedTargets = scienceTargets.filter(t => 
    astronautTelemetry.completedObservations.includes(t.id) || 
    selectedRoute.scienceTargetsVisited.some(st => st.id === t.id)
  );

  const totalScienceCollected = visitedTargets.reduce((acc, t) => acc + t.scientificValue, 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md select-none print:p-0 print:bg-white">
      <div className="bg-[#0b0f19] border border-[#38bdf8]/40 rounded-lg shadow-2xl max-w-3xl w-full max-h-[92vh] flex flex-col overflow-hidden text-gray-200 print:text-black print:bg-white print:border-none print:shadow-none">
        {/* Header */}
        <div className="p-4 border-b border-[#1e293b] bg-[#0d1322] flex items-center justify-between print:border-b-2 print:border-black">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-[#10b981]/15 text-[#10b981] rounded border border-[#10b981]/30">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <div className="text-[10px] font-mono text-[#38bdf8] uppercase tracking-widest font-semibold">
                PLANETARY SURFACE OPERATIONS DEBRIEF
              </div>
              <h2 className="text-lg font-heading font-bold text-white tracking-wide">
                MARSWEAVE EVA MISSION REPORT
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2 print:hidden">
            <button
              onClick={() => window.print()}
              className="px-3 py-1.5 bg-[#1e293b] hover:bg-[#334155] text-gray-200 rounded font-mono text-xs flex items-center gap-1.5 transition"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>PRINT REPORT</span>
            </button>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-white p-1.5 rounded hover:bg-[#1e293b] transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Report Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-xs font-mono">
          {/* Mission Classification Bar */}
          <div className="bg-[#0f172a] border border-[#1e293b] p-3 rounded grid grid-cols-2 md:grid-cols-4 gap-3 text-center">
            <div>
              <span className="text-[9px] text-gray-400 block">MISSION ID</span>
              <span className="text-sm font-bold text-white">ARCADIA-EVA-01</span>
            </div>
            <div>
              <span className="text-[9px] text-gray-400 block">PRIMARY OBJECTIVE</span>
              <span className="text-sm font-bold text-[#e25c2b]">{profile.objective}</span>
            </div>
            <div>
              <span className="text-[9px] text-gray-400 block">MARTIAN DATE</span>
              <span className="text-sm font-bold text-white">SOL {environment.sol}</span>
            </div>
            <div>
              <span className="text-[9px] text-gray-400 block">MISSION RESULT</span>
              <span className="text-sm font-bold text-emerald-400 flex items-center justify-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                ACCOMPLISHED
              </span>
            </div>
          </div>

          {/* Section 1: Surface Odometry & Travel Profile */}
          <div className="space-y-2">
            <h3 className="text-xs font-heading font-bold text-[#38bdf8] uppercase tracking-wider flex items-center gap-1.5">
              <Mountain className="w-4 h-4" />
              1. SURFACE TRAVERSE & TERRAIN PERFORMANCE
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-center bg-[#090d16] border border-gray-800 p-3 rounded">
              <div>
                <span className="text-[9px] text-gray-500 block">TRAVERSE DISTANCE</span>
                <span className="text-base font-bold text-white">{selectedRoute.totalDistanceKm} KM</span>
              </div>
              <div>
                <span className="text-[9px] text-gray-500 block">TOTAL EVA TIME</span>
                <span className="text-base font-bold text-[#38bdf8]">{selectedRoute.totalDurationMin} MIN</span>
              </div>
              <div>
                <span className="text-[9px] text-gray-500 block">AVERAGE SLOPE</span>
                <span className="text-base font-bold text-emerald-400">{selectedRoute.avgSlopeDeg}°</span>
              </div>
              <div>
                <span className="text-[9px] text-gray-500 block">MAX SLOPE ENCOUNTERED</span>
                <span className="text-base font-bold text-gray-300">{selectedRoute.maxSlopeDeg}°</span>
              </div>
            </div>
          </div>

          {/* Section 2: Scientific Harvest Catalog */}
          <div className="space-y-2">
            <h3 className="text-xs font-heading font-bold text-[#facc15] uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-4 h-4" />
              2. SCIENTIFIC OBSERVATIONS & ISRU HARVEST
            </h3>
            <div className="bg-[#090d16] border border-gray-800 p-3 rounded space-y-2">
              <div className="flex items-center justify-between text-[11px] pb-1.5 border-b border-gray-800">
                <span>TOTAL SCIENCE TARGETS VISITED:</span>
                <span className="font-bold text-[#facc15]">{visitedTargets.length} TARGETS ({totalScienceCollected} PTS)</span>
              </div>

              <div className="space-y-1.5">
                {visitedTargets.map(t => (
                  <div key={t.id} className="bg-[#0f172a] p-2 rounded flex items-center justify-between border border-gray-800">
                    <div>
                      <span className="text-[#38bdf8] font-bold mr-2">{t.id}</span>
                      <span className="text-white">{t.name}</span>
                    </div>
                    <div className="text-right">
                      <span className="text-emerald-400 font-semibold">{t.scientificValue} PTS</span>
                      <span className="text-[9px] text-gray-500 block">{t.dataSources[0]}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Section 3: Safety & Life-Support Margins */}
          <div className="space-y-2">
            <h3 className="text-xs font-heading font-bold text-[#10b981] uppercase tracking-wider flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4" />
              3. ASTRONAUT SAFETY & LOGISTICS MARGINS
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2 bg-[#090d16] border border-gray-800 p-3 rounded">
              <div>
                <span className="text-[9px] text-gray-500 block">FINAL SUIT BATTERY</span>
                <span className="text-sm font-bold text-amber-400">
                  {Math.round(astronautTelemetry.suitBatteryRemainingPct)}% REMAINING
                </span>
              </div>
              <div>
                <span className="text-[9px] text-gray-500 block">FINAL PRIMARY O2</span>
                <span className="text-sm font-bold text-emerald-400">
                  {Math.round(astronautTelemetry.suitO2RemainingPct)}% REMAINING
                </span>
              </div>
              <div>
                <span className="text-[9px] text-gray-500 block">MRO RELAY LINK</span>
                <span className="text-sm font-bold text-[#38bdf8]">
                  {selectedRoute.commsCoveragePct}% AVERAGE
                </span>
              </div>
            </div>
          </div>

          {/* Section 4: Data Provenance & Archival Citations */}
          <div className="pt-2 border-t border-gray-800 text-[10px] text-gray-500 space-y-1">
            <div className="font-bold text-gray-400">NASA DATASET & MISSION INTEGRATION CREDITS:</div>
            <div>• MOLA Altimetry (MGS) • HiRISE Camera (MRO) • CRISM Spectrometer (MRO)</div>
            <div>• SHARAD Radar (MRO/ASI) • THEMIS Thermal (Odyssey) • MEDA Weather (Perseverance) • RAD Radiation (MSL)</div>
            <div className="text-[9px] text-gray-600 mt-2">
              Generated by MARSWEAVE Autonomous EVA Planning Engine. Referenced to Mars MOLA 0-datum.
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-[#1e293b] bg-[#0d1322] flex items-center justify-between print:hidden">
          <button
            onClick={() => {
              onRestartMission();
              onClose();
            }}
            className="px-4 py-2 bg-[#1e293b] hover:bg-[#334155] text-white rounded font-mono text-xs flex items-center gap-1.5 transition cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>START NEW MISSION</span>
          </button>

          <button
            onClick={onClose}
            className="px-5 py-2 bg-[#38bdf8] hover:bg-[#0284c7] text-black font-heading font-bold text-xs rounded transition shadow"
          >
            DISMISS REPORT
          </button>
        </div>
      </div>
    </div>
  );
};
