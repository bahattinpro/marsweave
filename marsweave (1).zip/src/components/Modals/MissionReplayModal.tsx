/**
 * MARSWEAVE — Post-EVA Mission Replay Modal
 * Visualizes the chronological timeline of key decisions, route adaptations, and sampling events.
 */

import React, { useState } from 'react';
import {
  Clock,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Sparkles,
  Mountain,
  Compass,
  ArrowRight,
  X
} from 'lucide-react';

interface MissionReplayModalProps {
  isOpen: boolean;
  onClose: () => void;
  plannedDistanceKm: number;
  actualDistanceKm: number;
  totalTimeMin: number;
  samplesCount: number;
  replanningCount: number;
}

export const MissionReplayModal: React.FC<MissionReplayModalProps> = ({
  isOpen,
  onClose,
  plannedDistanceKm,
  actualDistanceKm,
  totalTimeMin,
  samplesCount,
  replanningCount
}) => {
  const [activeStep, setActiveStep] = useState<number>(0);

  if (!isOpen) return null;

  const events = [
    {
      time: 'T+00:00',
      title: 'MISSION COMMENCEMENT',
      desc: 'Astronaut depressurizes airlock and egresses Habitat Alpha into Arcadia Planitia. Base MRO satellite relay nominal.',
      type: 'START'
    },
    {
      time: 'T+24:15',
      title: 'TRAVERSE SCARP MARGIN',
      desc: 'Explorer negotiates smooth bench gradient (11.4° slope), avoiding the 34° unstable scree crater rim.',
      type: 'TERRAIN'
    },
    {
      time: 'T+38:40',
      title: 'SCIENCE STOP: TARGET 04 (PERIGLACIAL ICE)',
      desc: 'In-situ ground penetrating radar probe deployed. Confirms subsurface dielectric permittivity ε = 3.12 consistent with pure sheet ice at 1.8m depth.',
      type: 'SCIENCE'
    },
    {
      time: 'T+51:20',
      title: 'ATMOSPHERIC DUST FRONT SURGE',
      desc: 'MRO MARCI synoptic imaging alerts mission control of incoming dust front (tau surged to 1.88). Slope traction degraded.',
      type: 'ALERT'
    },
    {
      time: 'T+53:45',
      title: 'DYNAMIC CONTINGENCY REPLANNING',
      desc: 'Optimizer recalculates traversal vector. Directs explorer onto firm bedrock bench to maintain footing and preserve relay line-of-sight.',
      type: 'REPLAN'
    },
    {
      time: 'T+84:10',
      title: 'SCIENCE STOP: TARGET 07 (PHYLLOSILICATES)',
      desc: 'Drill core and contact spectrometer deployed. Diagnostic 1.41µm and 1.92µm absorption doublets confirmed in smectite clay outcrop.',
      type: 'SCIENCE'
    },
    {
      time: `T+${Math.round(totalTimeMin)}:00`,
      title: 'MISSION ACCOMPLISHED',
      desc: 'Crew ingress and sample container sealed. Traversed 4.72 km with 28 minutes of primary oxygen remaining.',
      type: 'COMPLETE'
    }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm select-none">
      <div className="bg-[#0f131c] border border-[#222a38] max-w-2xl w-full flex flex-col overflow-hidden text-[#d6d9e0] shadow-2xl">
        {/* Header */}
        <div className="p-4 bg-[#141822] hairline-b flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 bg-[#3898b8]/15 text-[#3898b8] rounded border border-[#3898b8]/30">
              <Clock className="w-4 h-4" />
            </div>
            <div>
              <div className="text-[10px] font-mono text-[#3898b8] tracking-wider uppercase font-semibold">
                POST-FLIGHT CHRONOLOGY
              </div>
              <h2 className="text-base font-bold text-white font-sans tracking-tight">
                MISSION REPLAY & TIMELINE AUDIT
              </h2>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-[#8b95a5] hover:text-white p-1 rounded hover:bg-[#1a202c] transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6 text-xs font-sans overflow-y-auto max-h-[75vh]">
          {/* Comparison Summary */}
          <div className="grid grid-cols-4 gap-3 text-center font-mono text-xs bg-[#0b0e14] p-3 border border-[#1c2230]">
            <div>
              <span className="text-[10px] text-[#6b7788] block">PLANNED DIST</span>
              <span className="text-white font-semibold">{plannedDistanceKm} km</span>
            </div>
            <div>
              <span className="text-[10px] text-[#6b7788] block">ACTUAL TRAVERSE</span>
              <span className="text-[#3898b8] font-semibold">{actualDistanceKm} km</span>
            </div>
            <div>
              <span className="text-[10px] text-[#6b7788] block">DECISION REPLANS</span>
              <span className="text-[#c85a32] font-semibold">{replanningCount || 1} EVENT</span>
            </div>
            <div>
              <span className="text-[10px] text-[#6b7788] block">SAMPLES LOGGED</span>
              <span className="text-[#48b577] font-semibold">{samplesCount || 2} SAMPLES</span>
            </div>
          </div>

          {/* Interactive Chronological Timeline */}
          <div className="space-y-4">
            <span className="font-mono text-[10px] text-[#8b95a5] uppercase tracking-wider block font-semibold">
              CHRONOLOGICAL EVENT LOG:
            </span>

            <div className="space-y-3 font-mono text-xs">
              {events.map((ev, idx) => {
                const isSelected = idx === activeStep;
                return (
                  <div
                    key={idx}
                    onClick={() => setActiveStep(idx)}
                    className={`p-3.5 border transition cursor-pointer flex items-start gap-3.5 ${
                      isSelected
                        ? 'bg-[#141a26] border-[#3898b8] text-white'
                        : 'bg-[#0b0e14] border-[#1c2230] text-[#8b95a5] hover:border-gray-700 hover:text-[#cdd3de]'
                    }`}
                  >
                    <div className="font-bold text-[#c85a32] shrink-0 text-[11px] pt-0.5">
                      {ev.time}
                    </div>

                    <div className="space-y-1 font-sans flex-1">
                      <div className="font-mono font-semibold text-xs text-white flex items-center justify-between">
                        <span>{ev.title}</span>
                        <span className={`text-[9px] px-1.5 py-0.5 rounded font-mono ${
                          ev.type === 'ALERT'
                            ? 'bg-amber-950 text-amber-400 border border-amber-800'
                            : ev.type === 'SCIENCE'
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                            : ev.type === 'REPLAN'
                            ? 'bg-sky-950 text-sky-400 border border-sky-800'
                            : 'bg-gray-800 text-gray-300'
                        }`}>
                          {ev.type}
                        </span>
                      </div>
                      <p className="text-xs text-[#8b95a5] leading-relaxed">
                        {ev.desc}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#141822] hairline-t flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-[#1c2230] hover:bg-[#252c3d] text-white font-mono text-xs rounded transition cursor-pointer"
          >
            CLOSE REPLAY
          </button>
        </div>
      </div>
    </div>
  );
};
