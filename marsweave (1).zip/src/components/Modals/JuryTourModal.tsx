/**
 * MARSWEAVE — NASA Space Apps Challenge Jury Tour & Presentation Mode
 * 2-3 minute guided walkthrough demonstrating:
 * 1. Heterogeneous NASA Data Fusion
 * 2. Multi-Objective A* Route Optimization
 * 3. Explainable "WHY THIS ROUTE?"
 * 4. In-Situ Scientific Sampling
 * 5. Dynamic Environmental Adaptation (Dust Surge Re-planning)
 * 6. Mission Debrief & Provenance
 */

import React, { useState } from 'react';
import {
  Compass,
  Play,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  X,
  Sparkles,
  ShieldAlert,
  Database,
  RefreshCw,
  Award
} from 'lucide-react';

interface JuryTourStep {
  title: string;
  tag: string;
  description: string;
  actionText: string;
  highlight: string;
  onApplyStep?: () => void;
}

interface JuryTourModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTriggerPlanEva: () => void;
  onSelectScienceObjective: (obj: any) => void;
  onToggleLayer: (id: string) => void;
  onTriggerDustScenario: () => void;
  onTriggerReplanning: () => void;
  onOpenReport: () => void;
  onOpenProvenance: () => void;
}

export const JuryTourModal: React.FC<JuryTourModalProps> = ({
  isOpen,
  onClose,
  onTriggerPlanEva,
  onSelectScienceObjective,
  onToggleLayer,
  onTriggerDustScenario,
  onTriggerReplanning,
  onOpenReport,
  onOpenProvenance
}) => {
  const [currentStepIdx, setCurrentStepIdx] = useState<number>(0);

  if (!isOpen) return null;

  const steps: JuryTourStep[] = [
    {
      title: 'THE CORE PARADIGM',
      tag: 'CHALLENGE SOLUTION',
      description: 'Future astronauts on Mars do not need another passive static map with toggles. They need an intelligent system that turns heterogeneous NASA orbital observations into an explainable, multi-objective EVA mission plan.',
      highlight: '"THE BEST ROUTE IS MISSION-DEPENDENT."',
      actionText: 'START GUIDED DEMO'
    },
    {
      title: '1. MULTI-MISSION NASA DATA FUSION',
      tag: 'OBSERVE',
      description: 'MARSWEAVE calibrates MOLA altimetry, HiRISE 25cm boulder textures, SHARAD shallow radar ice sheets, CRISM hyperspectral minerals, THEMIS thermal inertia, and MSL RAD surface radiation into a single operational coordinate frame.',
      highlight: '10 NASA mission datasets fused across Arcadia Planitia.',
      actionText: 'ACTIVATE CRISM & SHARAD LAYERS',
      onApplyStep: () => {
        onToggleLayer('crism_minerals');
        onToggleLayer('sharad_ice');
      }
    },
    {
      title: '2. OBJECTIVE-DRIVEN A* OPTIMIZATION',
      tag: 'PLAN',
      description: 'Unlike standard GPS shortest-path algorithms, MARSWEAVE optimizes for Science Value, Terrain Slope Penalties, Boulder Hazards, Line-of-Sight Communication with the Mars Relay Network, and Life-Support Margins.',
      highlight: 'Computes Route Alpha (Balanced), Route Beta (Science Yield), and Route Gamma (Direct).',
      actionText: 'CALCULATE EVA ROUTES',
      onApplyStep: () => {
        onTriggerPlanEva();
      }
    },
    {
      title: '3. EXPLAINABILITY: "WHY THIS ROUTE?"',
      tag: 'UNDERSTAND',
      description: 'The system explains why Route Alpha was selected: 18% lower slope exposure, 31% lower hazard risk, 2 high-value mineral targets intercepted, and complete avoidance of the 34° scree crater rim.',
      highlight: 'Explainable AI grounded in real physics and orbital telemetry.',
      actionText: 'NEXT: IN-SITU SAMPLING'
    },
    {
      title: '4. LIVE EVA SIMULATION & SAMPLING',
      tag: 'WALK & DISCOVER',
      description: 'As the astronaut traverses the route, life support telemetry updates in real-time. Approaching Target SCI-07 prompts a multi-spectral observation with full evidence chain traceability.',
      highlight: 'Simulates physical metabolic rates, suit battery, and science protocol execution.',
      actionText: 'SIMULATE DUST SURGE EVENT',
      onApplyStep: () => {
        onTriggerDustScenario();
      }
    },
    {
      title: '5. DYNAMIC REPLANNING & ADAPTATION',
      tag: 'ADAPT',
      description: 'When regional dust optical depth (tau) surges, the current route becomes hazardous. MARSWEAVE automatically detects route degradation and re-routes around oncoming sediment corridors.',
      highlight: 'Instant side-by-side comparison: Risk Delta -22%, Comms Delta +11%.',
      actionText: 'TRIGGER DYNAMIC REPLAN',
      onApplyStep: () => {
        onTriggerReplanning();
      }
    },
    {
      title: '6. MISSION DEBRIEF & PROVENANCE',
      tag: 'DEBRIEF & CITATIONS',
      description: 'At mission completion, an aerospace EVA debrief report catalogs visited science samples, terrain metrics, and full NASA PDS archival citations.',
      highlight: 'NASA PDS Release 78 compliance and scientific transparency.',
      actionText: 'VIEW MISSION REPORT',
      onApplyStep: () => {
        onOpenReport();
      }
    }
  ];

  const currentStep = steps[currentStepIdx];

  const handleNext = () => {
    if (currentStep.onApplyStep) {
      currentStep.onApplyStep();
    }
    if (currentStepIdx < steps.length - 1) {
      setCurrentStepIdx(i => i + 1);
    } else {
      onClose();
    }
  };

  const handlePrev = () => {
    if (currentStepIdx > 0) {
      setCurrentStepIdx(i => i - 1);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm select-none">
      <div className="bg-[#0b0f19] border border-[#e25c2b]/50 rounded-lg shadow-2xl max-w-xl w-full flex flex-col overflow-hidden text-gray-200">
        {/* Header */}
        <div className="p-4 border-b border-[#1e293b] bg-[#0d1322] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 bg-[#e25c2b]/20 text-[#e25c2b] rounded">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-mono text-[#e25c2b] tracking-widest font-semibold block">
                NASA SPACE APPS 2026 JURY PRESENTATION
              </span>
              <h2 className="text-base font-heading font-bold text-white tracking-wide">
                MARSWEAVE 2-MINUTE DEMO FLOW
              </h2>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white p-1 rounded hover:bg-[#1e293b]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Body */}
        <div className="p-6 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono bg-amber-500/15 border border-amber-500/30 text-amber-300 px-2 py-0.5 rounded font-semibold">
              STEP {currentStepIdx + 1} OF {steps.length} • {currentStep.tag}
            </span>
            <div className="flex gap-1">
              {steps.map((_, idx) => (
                <div
                  key={idx}
                  className={`w-4 h-1.5 rounded-full transition ${
                    idx === currentStepIdx
                      ? 'bg-[#e25c2b]'
                      : idx < currentStepIdx
                      ? 'bg-emerald-500'
                      : 'bg-gray-800'
                  }`}
                />
              ))}
            </div>
          </div>

          <h3 className="text-base font-heading font-bold text-white tracking-wide">
            {currentStep.title}
          </h3>

          <p className="text-xs text-gray-300 leading-relaxed font-sans">
            {currentStep.description}
          </p>

          <div className="bg-[#0f172a] border border-[#1e293b] p-3 rounded text-center">
            <span className="text-xs font-mono font-bold text-[#38bdf8]">
              {currentStep.highlight}
            </span>
          </div>
        </div>

        {/* Footer Navigation */}
        <div className="p-4 border-t border-[#1e293b] bg-[#0c121e] flex items-center justify-between">
          <button
            onClick={handlePrev}
            disabled={currentStepIdx === 0}
            className="px-3 py-1.5 rounded bg-gray-800 hover:bg-gray-700 disabled:opacity-30 text-gray-300 font-mono text-xs flex items-center gap-1.5 transition cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>PREVIOUS</span>
          </button>

          <button
            onClick={handleNext}
            className="px-5 py-2 rounded bg-gradient-to-r from-[#e25c2b] to-[#ea580c] hover:from-[#d14f20] hover:to-[#c2410c] text-white font-heading font-bold text-xs tracking-wider shadow-lg shadow-[#e25c2b]/25 flex items-center gap-2 transition cursor-pointer"
          >
            <span>{currentStep.actionText}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
