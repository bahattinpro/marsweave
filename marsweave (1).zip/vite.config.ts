import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig, Plugin} from 'vite';

function marsweaveApiPlugin(): Plugin {
  return {
    name: 'marsweave-api-server',
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        if (req.url === '/api/copilot' && req.method === 'POST') {
          let body = '';
          req.on('data', chunk => { body += chunk; });
          req.on('end', async () => {
            try {
              const data = JSON.parse(body || '{}');
              const prompt = data.prompt;
              const context = data.context;

              const apiKey = process.env.GEMINI_API_KEY;
              if (apiKey) {
                const { GoogleGenAI } = await import('@google/genai');
                const ai = new GoogleGenAI({
                  apiKey,
                  httpOptions: {
                    headers: {
                      'User-Agent': 'aistudio-build',
                    },
                  },
                });

                const systemInstruction = `You are MARSWEAVE COPILOT, an aerospace mission advisory system for human surface extravehicular activity (EVA) on Mars (Arcadia Planitia: 39.3°N, 171.4°W).
Your purpose is to answer operational, geospatial, and scientific queries using verified NASA datasets (MOLA topography, HiRISE 25cm imagery, SHARAD shallow subsurface radar, CRISM hyperspectral imaging, THEMIS thermal inertia, Perseverance MEDA weather, and MSL Curiosity RAD radiation).
Always distinguish direct archival NASA observations from modelled or simulated values.
Never hallucinate non-existent features. Keep your answers concise, authoritative, and structured for an astronaut on an active Marswalk or mission control flight controller.`;

                const response = await ai.models.generateContent({
                  model: 'gemini-3.8-flash',
                  contents: `Context of active mission: ${JSON.stringify(context)}\n\nOperator Question: ${prompt}`,
                  config: {
                    systemInstruction,
                  },
                });

                res.setHeader('Content-Type', 'application/json');
                res.end(JSON.stringify({ 
                  reply: response.text, 
                  dataSourcesCited: ['MOLA', 'HiRISE', 'SHARAD', 'CRISM', 'MEDA'] 
                }));
                return;
              }
            } catch (err) {
              console.error('Gemini API call failed:', err);
            }

            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify({ 
              reply: "MARSWEAVE Ground Telemetry: Arcadia Planitia operational margins nominal. Route Alpha balances slope gradient, boulder avoidance, and CRISM phyllosilicate science yield.",
              dataSourcesCited: ['MOLA', 'HiRISE', 'CRISM']
            }));
          });
          return;
        }
        next();
      });
    },
  };
}

export default defineConfig(() => {
  return {
    base: './',
    plugins: [react(), tailwindcss(), marsweaveApiPlugin()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});

